import { useState } from "react";
import { CodeBlock, Pill, Section } from "./components/ui";
import FrameModel from "./components/FrameModel";
import ConfigBuilder from "./components/ConfigBuilder";
import { causes, checklist, diagnostics, FULL_MODE_KEYS, patches } from "./data/content";

const NAV = [
  ["tldr", "结论速览"],
  ["fullmode", "什么是完全模式"],
  ["symptom", "低占用意味着什么"],
  ["causes", "根因排序"],
  ["patches", "补丁方案"],
  ["diagnose", "实测与证伪"],
  ["config", "玩家侧缓解"],
  ["ship", "交付与验收"],
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#07090c] text-zinc-300 antialiased">
      <Backdrop />
      <Header />
      <main className="relative mx-auto max-w-5xl px-5 pb-32 sm:px-8">
        <Hero />
        <Tldr />
        <FullMode />
        <Symptom />
        <Causes />
        <Patches />
        <Diagnose />
        <ConfigSection />
        <Ship />
        <Footer />
      </main>
    </div>
  );
}

function Backdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      <div className="absolute -top-40 left-1/2 h-[38rem] w-[38rem] -translate-x-1/2 rounded-full bg-amber-500/10 blur-[120px]" />
      <div className="absolute bottom-0 right-0 h-[28rem] w-[28rem] rounded-full bg-sky-600/10 blur-[120px]" />
      <div
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.03) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
        }}
      />
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-30 border-b border-white/5 bg-[#07090c]/80 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center gap-4 px-5 py-3 sm:px-8">
        <div className="flex items-center gap-2">
          <ScopeGlyph />
          <span className="font-mono text-sm text-zinc-200">TaCZ · Scope PIP</span>
        </div>
        <nav className="ml-auto hidden gap-1 md:flex">
          {NAV.map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              className="rounded-md px-2.5 py-1.5 text-xs text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200"
            >
              {label}
            </a>
          ))}
        </nav>
        <a
          href="https://github.com/q14433686-arch/TaCZ_Refabricated_Unofficial"
          target="_blank"
          rel="noreferrer"
          className="rounded-md border border-white/10 px-2.5 py-1.5 font-mono text-[11px] text-zinc-400 transition hover:border-amber-400/40 hover:text-amber-300"
        >
          26.2(main)
        </a>
      </div>
    </header>
  );
}

function ScopeGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6 text-amber-400">
      <circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth="1" opacity=".6" />
      <path d="M12 1.5v5M12 17.5v5M1.5 12h5M17.5 12h5" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function Hero() {
  return (
    <div className="pt-16 pb-4 sm:pt-24">
      <div className="mb-5 flex flex-wrap gap-2">
        <Pill tone="amber">性能缺陷分析</Pill>
        <Pill>Minecraft 26.2 · Fabric</Pill>
        <Pill>Iris 1.11.x + Sodium 0.9.x + Voxy</Pill>
        <Pill tone="rose">未实机验证</Pill>
      </div>
      <h1 className="text-3xl font-semibold leading-tight tracking-tight text-zinc-50 sm:text-5xl">
        开启 PIP 的「完全模式」后
        <br />
        <span className="text-amber-300">帧率腰斩，CPU 与显卡占用率却上不去</span>
      </h1>
      <p className="mt-6 max-w-3xl text-[15px] leading-relaxed text-zinc-400">
        这不是「显卡不够强」。<strong className="text-zinc-200">占用率上不去恰恰是病征本身</strong>
        ——一帧里有大段时间谁都没在干活：GPU 队列排空、主线程在等回执、工作线程拿不到任务。
        本文按仓库现有代码与注释（<code className="font-mono text-xs text-zinc-300">ScopePipRenderer</code>、
        <code className="font-mono text-xs text-zinc-300">IrisScopePipelineCompat</code>、
        <code className="font-mono text-xs text-zinc-300">ScopePipTarget</code>、
        <code className="font-mono text-xs text-zinc-300">docs/SCOPE_PIP_HANDOFF</code>）定位停顿来源，
        给出分级补丁、证伪方法与验收清单。
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <a
          href="#tldr"
          className="rounded-lg bg-amber-400 px-4 py-2.5 text-sm font-medium text-black transition hover:bg-amber-300"
        >
          直接看结论
        </a>
        <a
          href="#patches"
          className="rounded-lg border border-white/15 px-4 py-2.5 text-sm text-zinc-200 transition hover:border-amber-400/40 hover:text-amber-300"
        >
          看补丁代码
        </a>
      </div>
    </div>
  );
}

function Tldr() {
  return (
    <Section
      id="tldr"
      index="§0"
      title="一页纸结论"
      kicker="先说能立刻用的，再说为什么。"
    >
      <div className="grid gap-4 md:grid-cols-3">
        {[
          {
            t: "病因不是算力，是串行",
            d: "完全模式把一帧变成「两遍完整 Iris 管线 + 一次全屏拷贝 + 两次管线切换」，且两遍复用同一套 RenderTargets ——「先读走再覆盖写」是帧内唯一的强序依赖，等待就发生在这里。",
            tone: "rose",
          },
          {
            t: "最贵的三件事",
            d: "① 两遍之间的全屏拷贝与屏障；② 镜内那遍重画了一整套阴影贴图；③ 镜内按全屏分辨率跑完 composite 链，而最终只有镜片那一小块会被看到。",
            tone: "amber",
          },
          {
            t: "改法都在闸门之后",
            d: "六条补丁全部只在 ScopePipEnable=true 的分支内生效；默认配置逐位不变。任何一条失败仍会命中既有的 failed 闸门，下一帧自动退回整屏变焦。",
            tone: "emerald",
          },
        ].map((c) => (
          <div key={c.t} className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <Pill tone={c.tone}>{c.t}</Pill>
            <p className="mt-3 text-sm leading-relaxed text-zinc-400">{c.d}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] p-5">
        <h3 className="text-sm font-medium text-amber-200">现在就能做的三步（不用等代码合并）</h3>
        <ol className="mt-3 space-y-2 text-sm text-zinc-300">
          <li>
            <span className="font-mono text-amber-300">1.</span> 关垂直同步与帧率上限再看一次占用率
            —— 双缓冲 VSync 的半速率跌落会伪装成一模一样的症状。
          </li>
          <li>
            <span className="font-mono text-amber-300">2.</span>{" "}
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-xs">ScopePipShadowScale = 0.25</code>
            ，先把镜内那条最贵的通道压下去。
          </li>
          <li>
            <span className="font-mono text-amber-300">3.</span>{" "}
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-xs">ScopePipWorldZoomShare = 0.4</code>
            ；若仍不可接受，把 <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-xs">ScopePipRerender</code> 改回
            false（退回重投影，光影下不再跑第二遍世界渲染）。
          </li>
        </ol>
      </div>
    </Section>
  );
}

function FullMode() {
  return (
    <Section
      id="fullmode"
      index="§1"
      title="「完全模式」到底是哪四个开关"
      kicker="代码里没有一个叫 FullMode 的字段；它是四个配置项同时为真时形成的那条路径。下面每一条的说明都取自对应类/方法的注释。"
    >
      <div className="overflow-hidden rounded-2xl border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/[0.04] text-[11px] uppercase tracking-widest text-zinc-500">
            <tr>
              <th className="px-4 py-3">配置键</th>
              <th className="px-4 py-3">完全模式取值</th>
              <th className="px-4 py-3">语义（注释来源）</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {FULL_MODE_KEYS.map((k) => (
              <tr key={k.key} className="align-top">
                <td className="px-4 py-4 font-mono text-[12.5px] text-amber-200">{k.key}</td>
                <td className="px-4 py-4 font-mono text-xs text-emerald-300">{k.value}</td>
                <td className="px-4 py-4">
                  <p className="text-zinc-400">{k.note}</p>
                  <p className="mt-1 font-mono text-[11px] text-zinc-600">{k.src}</p>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h3 className="text-sm font-medium text-zinc-200">这条路径一帧要做什么</h3>
          <ol className="mt-3 space-y-1.5 font-mono text-[12.5px] text-zinc-400">
            <li>① 切到 scope_pip 管线（Iris preparePipeline）</li>
            <li>② 窄 FOV 跑完整一轮：shadow → gbuffers → deferred → composite → final</li>
            <li>③ 把成品拷进 tacz_scope_pip（全屏、同格式、不降采样）</li>
            <li>④ 切回主管线，Sodium 的 hasUpdatedThisFrame 复位</li>
            <li>⑤ vanilla 那遍从头再跑一整轮（覆盖同一套 RenderTargets）</li>
            <li>⑥ 掩码定位镜片 → 合成 → 镜身 discard → 准星反向裁剪</li>
          </ol>
        </div>
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h3 className="text-sm font-medium text-zinc-200">作者自己在注释里已经承认的代价</h3>
          <blockquote className="mt-3 border-l-2 border-amber-400/40 pl-4 text-sm leading-relaxed text-zinc-400">
            「代价是<strong className="text-zinc-200">真实的</strong>：整条光影管线（含阴影贴图与 composite 链）跑两遍，
            帧率大约减半；时域效果（TAA、动态模糊）的历史每帧被推进两次，可能出现重影或噪点。」
            <footer className="mt-2 font-mono text-[11px] text-zinc-600">
              ScopePipRenderer#rerenderMode() · PR #66
            </footer>
          </blockquote>
          <p className="mt-4 text-sm text-zinc-400">
            也就是说「帧率减半」是<strong className="text-zinc-200">已知设计成本</strong>；
            但<strong className="text-amber-300">占用率不上去</strong>不在这个预期里 ——
            如果两遍都在满负荷干活，显卡应该是打满的。差的这一块就是本文要找的东西。
          </p>
        </div>
      </div>
    </Section>
  );
}

function Symptom() {
  return (
    <Section
      id="symptom"
      index="§2"
      title="「占用率上不去」是一条极强的线索"
      kicker="把一帧拆成 GPU 工作 / CPU 与驱动串行 / 纯停顿三类，勾选补丁看每一类怎么变。"
    >
      <div className="mb-6 grid gap-4 md:grid-cols-3">
        {[
          ["GPU 占用低 + 帧时间长", "GPU 队列有空窗：命令没有连续供给，或存在等待 CPU 回执的屏障。"],
          ["CPU 总占用也低", "主线程在阻塞等待；工作线程（区块构建、Voxy LOD）因主线程分发变慢而饿死。"],
          ["两者同时低", "唯一自洽的解释是串行依赖链，而不是任何一侧的算力瓶颈。"],
        ].map(([t, d]) => (
          <div key={t} className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-sm text-zinc-200">{t}</div>
            <p className="mt-2 text-xs leading-relaxed text-zinc-500">{d}</p>
          </div>
        ))}
      </div>
      <FrameModel />
    </Section>
  );
}

function Causes() {
  const [open, setOpen] = useState<string | null>(causes[0].id);
  const toneOf = (c: string) =>
    c === "高" ? "rose" : c === "中高" ? "amber" : c === "中" ? "sky" : "zinc";
  return (
    <Section
      id="causes"
      index="§3"
      title="根因排序（每条都附「怎么证伪」）"
      kicker="本项目已经有过 9 次「有理有据但错误」的归因，共同模式是症状像什么就修什么。所以这里每一条都必须能被一次实验推翻。"
    >
      <div className="space-y-3">
        {causes.map((c) => {
          const isOpen = open === c.id;
          return (
            <div
              key={c.id}
              className={`overflow-hidden rounded-2xl border transition ${
                isOpen ? "border-amber-400/30 bg-amber-400/[0.04]" : "border-white/10 bg-white/[0.02]"
              }`}
            >
              <button
                onClick={() => setOpen(isOpen ? null : c.id)}
                className="flex w-full items-center gap-4 px-5 py-4 text-left"
              >
                <span className="font-mono text-sm text-zinc-600">#{c.rank}</span>
                <span className="flex-1 text-sm font-medium text-zinc-100">{c.title}</span>
                <Pill tone={toneOf(c.confidence)}>{c.confidence}</Pill>
                <span className={`text-zinc-500 transition ${isOpen ? "rotate-180" : ""}`}>▾</span>
              </button>
              {isOpen && (
                <div className="space-y-4 border-t border-white/5 px-5 py-5 text-sm">
                  <Field label="位置">
                    <code className="font-mono text-[12.5px] text-sky-300">{c.where}</code>
                  </Field>
                  <Field label="机理">
                    <p className="leading-relaxed text-zinc-400">{c.why}</p>
                  </Field>
                  <Field label="依据">
                    <ul className="space-y-1.5 text-zinc-400">
                      {c.evidence.map((e, i) => (
                        <li key={i} className="flex gap-2">
                          <span className="text-amber-400/70">·</span>
                          <span className="leading-relaxed">{e}</span>
                        </li>
                      ))}
                    </ul>
                  </Field>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="rounded-xl border border-rose-400/20 bg-rose-400/[0.05] p-4">
                      <div className="text-[11px] uppercase tracking-widest text-rose-300/80">怎么证伪</div>
                      <p className="mt-1.5 leading-relaxed text-zinc-300">{c.falsify}</p>
                    </div>
                    <div className="rounded-xl border border-emerald-400/20 bg-emerald-400/[0.05] p-4">
                      <div className="text-[11px] uppercase tracking-widest text-emerald-300/80">对应补丁</div>
                      <p className="mt-1.5 leading-relaxed text-zinc-300">{c.fix}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </Section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-[11px] uppercase tracking-widest text-zinc-500">{label}</div>
      {children}
    </div>
  );
}

function Patches() {
  const [active, setActive] = useState(patches[0].id);
  const p = patches.find((x) => x.id === active)!;
  const tone = (t: string) => (t === "P0" ? "rose" : t === "P1" ? "amber" : "sky");
  return (
    <Section
      id="patches"
      index="§4"
      title="补丁方案（P0 → P2）"
      kicker="P0 去掉停顿本身；P1 削掉真正多余的工作量；P2 是兜底的降频。全部落在 ScopePipEnable 闸门之后。"
    >
      <div className="grid gap-6 lg:grid-cols-[minmax(0,18rem)_minmax(0,1fr)]">
        <div className="space-y-2">
          {patches.map((x) => (
            <button
              key={x.id}
              onClick={() => setActive(x.id)}
              className={`w-full rounded-xl border p-3.5 text-left transition ${
                active === x.id
                  ? "border-amber-400/40 bg-amber-400/[0.07]"
                  : "border-white/10 bg-white/[0.02] hover:border-white/20"
              }`}
            >
              <div className="mb-1.5 flex items-center gap-2">
                <Pill tone={tone(x.tier)}>{x.tier}</Pill>
              </div>
              <div className={`text-[13px] leading-snug ${active === x.id ? "text-amber-100" : "text-zinc-300"}`}>
                {x.title}
              </div>
            </button>
          ))}
        </div>
        <div className="space-y-4">
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <div className="font-mono text-[11px] text-sky-300">{p.file}</div>
            <h3 className="mt-2 text-lg font-medium text-zinc-100">{p.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-zinc-400">{p.summary}</p>
          </div>
          <CodeBlock code={p.code} lang={p.id === "swap" || p.id === "lensrect" ? "diff" : "java"} />
          <div className="rounded-2xl border border-rose-400/20 bg-rose-400/[0.05] p-5">
            <div className="text-[11px] uppercase tracking-widest text-rose-300/80">风险与退路</div>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">{p.risk}</p>
          </div>
        </div>
      </div>

      <div className="mt-8 rounded-2xl border border-white/10 bg-white/[0.02] p-5">
        <h3 className="text-sm font-medium text-zinc-200">落地顺序（一次只上一条，各自单独量化）</h3>
        <div className="mt-4 flex flex-wrap items-center gap-2 font-mono text-xs">
          {["P0-1 目标交换", "P0-2 禁帧内同步", "P0-3 切换去抖", "P1-1 阴影复用", "P1-2 镜片包围盒", "P1-3 通道白名单", "P2 降频"].map(
            (s, i, arr) => (
              <span key={s} className="flex items-center gap-2">
                <span className="rounded-md border border-white/10 bg-black/30 px-2.5 py-1.5 text-zinc-300">{s}</span>
                {i < arr.length - 1 && <span className="text-zinc-700">→</span>}
              </span>
            ),
          )}
        </div>
        <p className="mt-4 text-xs leading-relaxed text-zinc-500">
          合并成一个大 PR 会让「哪条真的有效」永远说不清 —— 本仓库的 handoff 文档里已经栽过一次
          （删掉 IrisScopePip 前后症状一模一样，说明它从来就不是原因）。每条独立提交、独立读数。
        </p>
      </div>
    </Section>
  );
}

function Diagnose() {
  return (
    <Section
      id="diagnose"
      index="§5"
      title="实测流程：把猜测变成读数"
      kicker="在拿到这几组数字之前，上面的排序只是假设。"
    >
      <div className="space-y-3">
        {diagnostics.map((d) => (
          <div key={d.step} className="flex gap-4 rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-amber-400/30 bg-amber-400/10 font-mono text-sm text-amber-300">
              {d.step}
            </div>
            <div>
              <h3 className="text-sm font-medium text-zinc-100">{d.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{d.detail}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <h3 className="mb-3 text-sm font-medium text-zinc-200">四象限记录表（照抄进 issue）</h3>
        <CodeBlock
          lang="markdown"
          code={`| 组合                                            | 平均帧时间 | 1% low | GPU 忙占比 | CPU 主线程 wait |
|-------------------------------------------------|-----------|--------|-----------|-----------------|
| A 基线：PIP 关，光影开                            |           |        |           |                 |
| B 完全模式（Enable+Rerender+AllowShader+Isolate） |           |        |           |                 |
| C = B 但 Isolate=false                           |           |        |           |                 |
| D = B 但 Rerender=false（重投影）                 |           |        |           |                 |
| E = B 但 ShadowScale=0.25                        |           |        |           |                 |

结论判读：
  B−D ≈ 第二遍世界渲染的全部成本
  B−C ≈ 管线隔离与切换的成本
  B−E ≈ 镜内阴影通道的成本
  若 (B−D)+(B−C)+(B−E) 明显小于 B−A，剩下的差额就是停顿 —— 那正是 P0 要消掉的部分。`}
        />
      </div>
    </Section>
  );
}

function ConfigSection() {
  return (
    <Section
      id="config"
      index="§6"
      title="玩家侧：现在就能用的四套配置"
      kicker="代码补丁合并前，先让人能玩。"
    >
      <ConfigBuilder />
    </Section>
  );
}

function Ship() {
  return (
    <Section id="ship" index="§7" title="验收清单与提交口径">
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <h3 className="text-sm font-medium text-zinc-200">验收清单</h3>
          <ul className="mt-4 space-y-2.5">
            {checklist.map((c) => (
              <li key={c} className="flex gap-3 text-sm text-zinc-400">
                <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border border-white/20 font-mono text-[9px] text-zinc-600">
                  ☐
                </span>
                <span className="leading-relaxed">{c}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="space-y-4">
          <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.05] p-5">
            <h3 className="text-sm font-medium text-amber-200">诚实标注（按仓库 AGENTS.md §2）</h3>
            <p className="mt-2 text-sm leading-relaxed text-zinc-300">
              本文全部结论为<strong>源码级推导</strong>，依据是 26.2(main) 的类注释、PR #66 的 diff 与
              docs/SCOPE_PIP_HANDOFF；<strong className="text-amber-200">未编译、未实机</strong>。
              提交 PR 时必须把「源码级」与「实机 PASS」分开写，不得把模型估算当实测数据。
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <h3 className="text-sm font-medium text-zinc-200">PR 标题建议</h3>
            <CodeBlock
              lang="text"
              code={`perf(scope-pip): 消除完全模式下的帧内停顿
  —— 目标交换替代全屏拷贝、阴影复用、镜片包围盒渲染

Fixes: 光影 + 二次渲染 + 管线隔离时帧率减半而 CPU/GPU
占用率不升（停顿主导，非算力瓶颈）`}
            />
          </div>
        </div>
      </div>
    </Section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/10 py-10 text-xs text-zinc-600">
      <p>
        面向 <span className="text-zinc-400">q14433686-arch/TaCZ_Refabricated_Unofficial · 26.2(main)</span> 的
        Scope PIP 性能分析。TaCZ 及本端口代码 GPL-3.0；本页仅为分析文档，不含任何游戏资源。
      </p>
      <p className="mt-2">
        引用：README §4.2 · PR #66 · docs/SCOPE_PIP_HANDOFF_2026_08_21.md · ScopePipRenderer /
        ScopePipTarget / IrisScopePipelineCompat 的类注释。
      </p>
    </footer>
  );
}
