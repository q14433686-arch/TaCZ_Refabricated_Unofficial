export type Cause = {
  id: string;
  rank: number;
  title: string;
  confidence: "高" | "中高" | "中" | "待证";
  where: string;
  why: string;
  evidence: string[];
  falsify: string;
  fix: string;
};

/** 「完全模式」在代码里的定义来源（逐条摘自 26.2(main) 的类/方法注释） */
export const FULL_MODE_KEYS = [
  {
    key: "ScopePipEnable",
    value: "true",
    note: "PIP 总开关。默认 false。关掉即回到上游整屏 FOV 变焦。",
    src: "README §4.2 / RenderConfig",
  },
  {
    key: "ScopePipRerender",
    value: "true",
    note:
      "「二次渲染」：用窄 FOV 把世界真画一遍，而不是把主画面重投影。注释原文：「整条光影管线（含阴影贴图与 composite 链）跑两遍，帧率大约减半」。",
    src: "ScopePipRenderer#rerenderMode()",
  },
  {
    key: "ScopePipAllowShaderPacks",
    value: "true",
    note: "光影（Iris）下放行 PIP。默认 false 是保守默认。",
    src: "README §4.2",
  },
  {
    key: "ScopePipIsolatePipeline",
    value: "true (默认)",
    note:
      "给镜内那一遍配一套独立的 Iris 管线（scope_pip 维度 id），时域状态与主画面彻底分开；Voxy 需要第二套渲染栈配合。",
    src: "ScopePipRenderer#isolatePipeline() / IrisScopePipelineCompat",
  },
];

export const causes: Cause[] = [
  {
    id: "serial",
    rank: 1,
    title: "两遍完整管线是严格串行的，帧内出现「谁都不忙」的等待窗口",
    confidence: "高",
    where:
      "ScopePipRenderer#renderScopePass → levelRenderer.render（镜内那遍）→ 取回成品 → vanilla 那遍",
    why:
      "注释写得很清楚：「镜内那遍先跑完（beginLevelRendering → … → finalizeLevelRendering 走完整轮），我们把成品拷走，vanilla 那遍再从头跑一次」。两遍复用同一套 Iris RenderTargets，因此第二遍必须等第一遍的成品被拷出来才能开始覆盖写。这条「写—读—再写」同一批纹理的依赖，在驱动层会插入隐式屏障；配合 Blaze3D 26.2 的 CommandEncoder 提交模型，主线程在提交第二遍前要等第一遍的拷贝完成。等待期间：GPU 队列排空（显卡占用掉下去），主线程在阻塞（CPU 单核也不满），而其它核心本来就闲 —— 于是「CPU 和显卡占用率都上不去，帧率却腰斩」。",
    evidence: [
      "PR #66 注释：「两遍复用同一套缓冲 —— 所以这条路不额外占显存，第二遍只是把第一遍的内容覆盖掉」——复用即串行依赖。",
      "ScopePipTarget 注释：拷贝是逐像素的 copyTextureToTexture，且尺寸与主帧缓冲严格一致、不做降采样。",
      "低占用 + 帧时间翻倍，是典型的 pipeline stall 特征，而非 ALU/带宽瓶颈（那种情况显卡会满载）。",
    ],
    falsify:
      "在镜内那遍与拷贝之间插入 GPU timer query（不要用 CPU 时钟），若 GPU 忙时间之和明显小于帧时间，则确认是等待而非算力。",
    fix: "P0-1 / P0-2：目标交换代替全屏拷贝 + 消除帧内隐式屏障。",
  },
  {
    id: "pipeswitch",
    rank: 2,
    title: "每帧两次 Iris preparePipeline 切换：驱动侧状态验证与 uniform 全量重建",
    confidence: "中高",
    where: "IrisScopePipelineCompat / IrisScopeDimensionMixin",
    why:
      "隔离模式下，一帧内「当前管线」要在主管线与 scope_pip 管线之间来回切换。preparePipeline 除了取/建，还会触碰 SystemTimeUniforms（COUNTER/TIMER reset 的坑注释里已经写过），并让整套 program/UBO/采样器重新绑定。切换本身跑在驱动线程上，是纯串行的 CPU 侧工作；游戏主线程和 GPU 都在等它 —— 又一段「占用率显示很低但时间在流逝」的空窗。",
    evidence: [
      "IrisScopePipelineCompat 的预热逻辑证明：管线构造会 reset 全局帧计数与计时器，在帧中途做会错乱。",
      "预热只解决「第一次编译」，不解决「每帧切换两次」的常驻成本。",
    ],
    falsify:
      "临时把 ScopePipIsolatePipeline 置为 false 实测：若占用率与帧率明显回升，则切换成本占大头。",
    fix: "P0-3：切换去抖 + 只在真正需要时切换 + 缓存管线句柄。",
  },
  {
    id: "shadow",
    rank: 3,
    title: "镜内那一遍重复画了一整套阴影贴图（几何提交在 CPU 侧，绘制批次极碎）",
    confidence: "中高",
    where: "ScopePipShadowScale（默认 0.5）+ Iris shadow pass",
    why:
      "shadow pass 与相机 FOV 无关：同一帧、同一光源、同一位置，镜内那遍的阴影贴图与主画面那遍在内容上等价。现在却完整重画一遍。阴影通道的特点是「绘制调用极多、每次几何量很小」，瓶颈在 CPU 提交与驱动，GPU 反而闲 —— 这正好制造低占用高耗时。",
    evidence: [
      "README §4.2：「ScopePipShadowScale = 0.5 # 镜内阴影贴图比例，默认值可省约 3/4 的镜内阴影开销」——说明镜内确有独立阴影通道。",
      "阴影贴图是视点相关而非投影相关；两遍相机位置一致，结果可复用。",
    ],
    falsify:
      "把 ScopePipShadowScale 调到 0.25 再测：若帧时间近似线性下降，则阴影通道占比大。",
    fix: "P1-1：镜内那遍复用主画面的 shadowtex，彻底跳过第二次 shadow render。",
  },
  {
    id: "fullres",
    rank: 4,
    title: "镜内那一遍按全屏分辨率渲染，但最终只有镜片那一小块会被看到",
    confidence: "高",
    where: "ScopePipTarget#getOrCreate（尺寸与主帧缓冲严格一致、不做降采样）",
    why:
      "重投影模式下「取满尺寸」是对的（源图就是主画面）。但二次渲染模式下，镜内成品只会经掩码贴进镜片外接矩形里 —— 屏幕上通常不到 8% 的面积。现在却按 100% 分辨率跑完整条光影管线（含 composite 链的每一遍全屏 pass）。这部分是纯浪费，且 composite 链的全屏 pass 数量多、每遍之间都有屏障，同样会把时间花在「切换与等待」上。",
    evidence: [
      "ScopePipTarget 类注释明确写「尺寸也取满，不做任何降采样」，其论证前提是重投影（拷贝）语义。",
      "PIP 的定义就是「只有镜片内放大」，镜片外接矩形之外的像素被掩码丢弃。",
    ],
    falsify:
      "把镜内 target 尺寸改成镜片外接矩形（按 ScopeMaskRenderer 已算好的 scissor 包围盒），量帧时间。",
    fix: "P1-2：镜内 viewport/target 收缩到镜片包围盒 + scissor。",
  },
  {
    id: "worker",
    rank: 5,
    title: "工作线程被饿死：区块构建/Voxy 异步节点整帧无事可做（CPU 总占用被拉低的直接原因）",
    confidence: "中",
    where: "Sodium RenderSectionManager / Voxy 视口状态 / 主线程独占",
    why:
      "帧时间翻倍时，主线程整帧都在提交与等待，任务分发变慢；Sodium 的区块构建、Voxy 的 LOD 构建拿不到新任务，多核 CPU 的总占用率自然掉下来。这不是病因，是病征 —— 但它正是玩家看到「CPU 占用不高」的那一半。历史上同一条链路还制造过一次显存爆掉（见 docs §2.9：渲染线程被拖慢 → 构建结果堆积 → 一次性上传 88MB → GpuOutOfMemoryException）。",
    evidence: [
      "docs/SCOPE_PIP_HANDOFF §2.9 已完整记录过「渲染线程慢 → 构建堆积 → 显存爆」的因果链。",
    ],
    falsify:
      "看 F3 的 chunk 更新队列与 Sodium 的 pending 数：若开完全模式后队列长期非空且构建线程空闲，即坐实。",
    fix: "随 P0/P1 一起消失；另加 P2-2 的镜内降频。",
  },
  {
    id: "vsync",
    rank: 6,
    title: "垂直同步 / 帧率上限造成的「占用率上不去」假象",
    confidence: "待证",
    where: "客户端视频设置，不在 mod 内",
    why:
      "两遍渲染让帧时间从 8ms 涨到 18ms，开着 60Hz 垂直同步就会直接掉到 30fps 这一档，而剩余时间被 sleep 掉 —— 表现正是「帧率减半 + 占用率不高」。必须先排除这条，否则后面的所有测量都不干净。",
    evidence: ["双缓冲 VSync 的半速率跌落是教科书现象。"],
    falsify: "关掉垂直同步、把最大帧率设为无限，再看占用率是否上来。",
    fix: "诊断前置步骤，不需要改代码。",
  },
];

export type Patch = {
  id: string;
  tier: "P0" | "P1" | "P2";
  title: string;
  file: string;
  summary: string;
  code: string;
  risk: string;
};

export const patches: Patch[] = [
  {
    id: "swap",
    tier: "P0",
    title: "用「目标交换」替掉两遍之间的全屏 copyTextureToTexture",
    file: "client/render/scope/ScopePipRenderer.java + ScopePipTarget.java",
    summary:
      "二次渲染模式下，镜内那遍本来就是画进 Iris 的 RenderTargets 的；随后再整屏拷进 tacz_scope_pip 是一次纯多余的全屏读写，且它是「第二遍必须等它完成」的那道屏障。改成：镜内那遍直接把 finalizeLevelRendering 的输出目标重定向到我们自己的 target（已有 redirectTarget() 机制），拷贝彻底取消。",
    code: `// ScopePipRenderer.java
-    // 镜内那遍画完 → 整屏拷进 PIP target
-    RenderSystem.getDevice().createCommandEncoder()
-            .copyTextureToTexture(mainColor, pipTarget.getColorTexture(),
-                    0, 0, 0, 0, 0, width, height);
+    // 【改】不再拷贝：镜内那遍从一开始就画进 PIP target。
+    // redirectTarget() 已经能覆盖 mainRenderTarget() 的解析（SkyRenderer 走
+    // SkyRendererMixin 的字段读取改写），Iris 的 finalize 阶段随之落到同一张目标上。
+    //
+    // 为什么这件事值 P0：两遍复用同一套 RenderTargets 时，「先读走再覆盖写」
+    // 是帧内唯一的强序依赖。取消之后，两遍只共享只读资源，驱动可以把第二遍的
+    // 命令排到第一遍后面而不必等待 CPU 侧的拷贝回执 —— 空窗消失，占用率回升。
+    beginRedirect(pipTarget);
     try {
         levelRenderer.render(...);
     } finally {
-        SodiumCompat.resetChunkUniformUpload();
+        endRedirect();
+        SodiumCompat.resetChunkUniformUpload(); // 这一条必须保留，见 handoff §1.2
     }`,
    risk:
      "需要确认 Iris 的 FinalPassRenderer 在隔离管线下也走 mainRenderTarget()；若否，退回拷贝但改成只拷镜片包围盒（见 P1-2），仍能去掉 90% 以上的拷贝量。",
  },
  {
    id: "fence",
    tier: "P0",
    title: "禁止在帧内做任何 CPU↔GPU 同步（fence / readback / 立即 map）",
    file: "client/render/scope/*",
    summary:
      "任何 mapBuffer、readBuffer、getPixels、以及「创建缓冲后立刻写并立刻用」的写法都会让主线程等 GPU。PR #66 已经把掩码顶点缓冲改成池化复用（正确方向），但要把这条规则推广到 PIP 路径的每一个资源，并加一个断言开关，防止将来回潮。",
    code: `/**
 * 【规则】PIP 路径禁止帧内同步点。
 *
 * 判据很简单：任何让主线程「知道 GPU 干完了」的调用都不许出现在
 * beginFrame..endFrame 之间 —— 包括 fence.awaitCompletion()、
 * GpuBuffer 的即时回读、以及 destroyBuffers() 后马上重建同名资源
 * （驱动会为了安全回收而插入等待）。
 *
 * 诊断计时一律用 GPU timer query，绝不用 System.nanoTime() 夹逼渲染调用：
 * 后者要么测不准，要么为了测准而自己引入 glFinish —— 那就是在制造本 bug。
 */
public static void assertNoFrameSync(String site) {
    if (!DEBUG_STRICT) return;
    if (RenderSystem.isOnRenderThread() && insideScopeLevelRender) {
        throw new IllegalStateException("[TACZ Scope] frame sync inside scope pass: " + site);
    }
}`,
    risk: "仅调试期开启（DEBUG_STRICT），发行版恒关，零成本。",
  },
  {
    id: "switch",
    tier: "P0",
    title: "管线切换去抖：一帧最多切两次，且不在切换里做任何构建",
    file: "compat/iris/IrisScopePipelineCompat.java",
    summary:
      "预热解决了首帧编译，但稳态下每帧仍要 preparePipeline 两次（进 scope、回主管线）。把「当前管线」的句柄缓存住，切换时只做引用替换；同时确保 Voxy 第二套栈的 ensureBuilt 只在真正重建时才跑（onLevelRendererReload 已给出破快速路径的事件，别每帧问）。",
    code: `// 稳态快速路径：把两套管线的句柄各缓存一份，切换退化成字段赋值。
private static Object cachedMainPipeline;
private static Object cachedScopePipeline;

/** @return true 表示已经切到瞄具管线；调用方负责在 finally 里 restore()。 */
public static boolean enterScopePipeline() {
    if (cachedScopePipeline == null || cachedMainPipeline == null) {
        return slowPathPrepare();      // 只在换 pack / 换维度 / 重载后跑一次
    }
    setCurrentPipeline(cachedScopePipeline);   // 纯字段写，不触发构造
    return true;
}

public static void restoreMainPipeline() {
    if (cachedMainPipeline != null) {
        setCurrentPipeline(cachedMainPipeline);
    }
}

// 失效点（唯一允许清缓存的地方）：
//   - PipelineManager.getPipelineNullable() 换了实例（重载光影包 / 切维度）
//   - onLevelRendererReload()（Voxy allChanged）`,
    risk:
      "setCurrentPipeline 是反射写 PipelineManager.pipeline 字段；若 Iris 改结构，回退到现有的 preparePipeline 路径（保留 slowPathPrepare 作为兜底）。",
  },
  {
    id: "shadow-reuse",
    tier: "P1",
    title: "镜内那一遍复用主画面的阴影贴图，跳过第二次 shadow render",
    file: "mixin/client/iris/IrisScopeShadowSkipMixin.java（新）",
    summary:
      "同一帧、同一相机位置、同一太阳角度 —— 镜内那遍的 shadowtex 与主画面逐字节等价。把 scope pass 的 shadow render 整个 short-circuit，改为绑定主管线上一次（同帧、先跑的那遍）的 shadow 附件。这是本方案里性价比最高的一刀：省掉一整条绘制调用极密集的通道。",
    code: `@Mixin(targets = "net.irisshaders.iris.pipeline.IrisRenderingPipeline", remap = false)
public abstract class IrisScopeShadowSkipMixin {

    /**
     * 镜内那一遍不重画阴影。
     *
     * 依据：shadow pass 的投影只取决于光源方向与相机<b>位置</b>，
     * 与相机 FOV 无关。镜内那遍与主画面同帧同位置 ⇒ 内容等价。
     *
     * 顺序前提：镜内那遍<b>先</b>跑，所以要么把两遍顺序调换（推荐），
     * 要么在镜内那遍照常画、由主画面那遍来复用。二者必居其一，
     * 关键是「一帧只画一次阴影」。
     */
    @Inject(method = "renderShadows", at = @At("HEAD"), cancellable = true)
    private void tacz$skipScopeShadows(CallbackInfo ci) {
        if (ScopePipRenderer.isInsideScopeLevelRender()
                && ScopePipShadowShare.mainShadowsValidThisFrame()) {
            ScopePipShadowShare.bindMainShadowTargets();
            ci.cancel();
        }
    }
}`,
    risk:
      "若 shaderpack 用了随 FOV 变化的 shadow distortion（少数 pack 会按视锥调整 shadow map 分布），镜内阴影可能略有偏差。提供 ScopePipShareShadows=true/false 开关，默认 true，出问题一键回退。",
  },
  {
    id: "lensrect",
    tier: "P1",
    title: "镜内 target 收缩到镜片包围盒，别按全屏跑 composite 链",
    file: "ScopePipTarget.java + ScopePipRenderer.java",
    summary:
      "二次渲染模式下把离屏 target 与 viewport 收到 ScopeMaskRenderer 已经算好的镜片外接矩形（合成阶段本来就在按它开 scissor）。像素量通常降到 5%~10%，全屏 composite 的每一遍也随之变小。注意保持宽高比与投影中心：只裁剪、不改投影，采样坐标用同一套 UV 映射。",
    code: `// ScopePipTarget#getOrCreate：二次渲染模式改用镜片包围盒尺寸
- target = new TextureTarget("tacz_scope_pip", w, h, needsDepth, format);
+ // 【改】重投影模式仍取满（源图就是主画面，降采样只会更糊）；
+ // 二次渲染模式取镜片外接矩形 —— 镜片之外的像素最终一定被掩码丢弃，
+ // 按全屏渲染等于把整条光影管线跑在 90% 用不上的像素上。
+ int tw = rerender ? Mth.clamp(lensRect.width(),  16, w) : w;
+ int th = rerender ? Mth.clamp(lensRect.height(), 16, h) : h;
+ target = new TextureTarget("tacz_scope_pip", tw, th, needsDepth, format);

// 投影不变、只改视口：镜内画面仍以光轴为中心，UV 映射同步按 lensRect 归一化。`,
    risk:
      "Iris 的 RenderTargets 尺寸跟随主帧缓冲，收缩需要在 scope pass 期间用 viewport+scissor 限定而非重建 target；若 pack 有依赖全屏尺寸的 composite，退回全屏并只降 50% 分辨率（ScopePipRenderScale）。",
  },
  {
    id: "passcull",
    tier: "P1",
    title: "镜内那一遍砍掉看不见的通道：手部、天气、云、粒子、实体描边、HUD 相关",
    file: "mixin/client/SimpleFeatureRenderPhaseMixin.java（已有）+ 新增闸门",
    summary:
      "镜内画面只需要世界几何与光照。第一人称手部（枪自己）在镜内是绝对不该出现的；天气、云、描边、绝大多数粒子对镜内观感贡献极低却要付完整提交成本。给镜内那一遍加一张「通道白名单」，并暴露成配置。",
    code: `/** 镜内那一遍要跑哪些通道。默认值按「看得见的收益 / 成本」排过序。 */
public static boolean tacz$shouldRunInScopePass(RenderPhase phase) {
    if (!ScopePipRenderer.isInsideScopeLevelRender()) return true;
    return switch (phase) {
        case HAND, OUTLINE, WEATHER, CLOUDS -> false;         // 镜内绝无必要
        case PARTICLES -> RenderConfig.SCOPE_PIP_PARTICLES.get();
        default -> true;
    };
}`,
    risk: "纯减法，最坏是镜内少了云/雨。全部可配置。",
  },
  {
    id: "cadence",
    tier: "P2",
    title: "镜内降频（ScopePipRerenderInterval）：每 N 帧真渲一次，中间帧用重投影补偿",
    file: "ScopePipRenderer.java",
    summary:
      "终极兜底：把「每帧两遍」变成「每 N 帧两遍」。中间帧沿用上一次镜内成品，并按这一帧与上一帧的相机旋转差做一次屏幕空间重投影修正（重投影的数学在本仓已经有了，就是 wideUV = center + (narrowUV−center)/Z 的同一套）。N=2 时镜内更新 30Hz、主画面照常 60Hz，人眼在高倍镜下几乎无感，而帧时间回到接近单遍。",
    code: `private static int frameParity;

private static boolean shouldRerenderThisFrame() {
    int interval = Math.max(1, RenderConfig.SCOPE_PIP_RERENDER_INTERVAL.get());
    if (interval == 1) return true;
    // 相机旋转超过阈值时强制刷新，避免快速甩枪出现镜内拖影
    if (cameraDeltaDeg() > 1.5f) return true;
    return (frameParity++ % interval) == 0;
}`,
    risk:
      "快速转身时镜内可能出现 1 帧的滞后；已用旋转阈值兜底。默认 interval=1（行为不变），玩家自选。",
  },
];

export const diagnostics = [
  {
    step: "0",
    title: "先把测量环境弄干净",
    detail:
      "关垂直同步、最大帧率设无限、关掉驱动的「垂直同步 / 帧率限制 / Threaded Optimization」全局覆盖；确认 mods/ 里只有一个 tacz jar（日志里认 `- tacz 1.1.8+fabric.26.2.R2-hotfix2` 这一行）。历史上有整整两个会话浪费在跑了旧 jar 上。",
  },
  {
    step: "1",
    title: "确认是「等待」而不是「算不动」",
    detail:
      "GPU 侧用 Nsight/RadeonGPUProfiler 抓一帧，看 GPU 忙时间之和 ÷ 帧时间。低于 60% 即为停顿主导。CPU 侧看主线程有没有长段 wait/futex —— 不要用 System.nanoTime 夹逼渲染调用去测，那会自己引入同步。",
  },
  {
    step: "2",
    title: "四象限消元法（每次只改一个开关，各测 60 秒平均帧时间）",
    detail:
      "① 完全模式全开 ② 关 ScopePipIsolatePipeline ③ 关 ScopePipRerender（退回重投影）④ 关 ScopePipAllowShaderPacks。差值直接把成本摊到「隔离切换 / 第二遍管线 / 光影本身」三项上。",
  },
  {
    step: "3",
    title: "阴影与分辨率的两次线性验证",
    detail:
      "ScopePipShadowScale 依次取 1.0 / 0.5 / 0.25，帧时间若近似线性，阴影通道就是大头（→ P1-1）。再把镜内 target 强制降到 50% 分辨率，若帧时间同样线性下降，则像素成本是大头（→ P1-2）。",
  },
  {
    step: "4",
    title: "别开 ScopePipDebugTrace",
    detail:
      "它每帧最多 400 次 StackWalker.walk()，挂在 mainRenderTarget() 上；且在光影下它的收摊条件永远不满足（docs §2.9），会整局常驻，最终以 Sodium 的 GpuOutOfMemoryException 收场。要 trace 就先加绝对帧数上限。",
  },
  {
    step: "5",
    title: "把结论写成读数而不是印象",
    detail:
      "本项目已有 9 次「有理有据但错误」的归因，共同模式都是「症状像什么就修什么」。提交结论时必须附：四象限表格、GPU 忙占比、以及改动前后各 60 秒的 1% low。",
  },
];

export const checklist = [
  "默认配置（ScopePipEnable=false）行为逐位不变——所有改动都在闸门之后",
  "无光影 + 二次渲染：镜内仍是原生分辨率，镜外仍是 1×",
  "光影 + 完全模式：帧时间较修改前下降，且 GPU 忙占比 > 80%",
  "Sodium 地形没有跟着镜内窄 FOV 变形（resetChunkUniformUpload 仍在 finally 里）",
  "Voxy：镜外远景无拉丝/错块；镜内有或没有 LOD 都可接受，但不能画错",
  "快速甩枪 60 秒：镜内无拖影、无残留；镜外实体不消失",
  "连续跑图 10 分钟：无 GpuOutOfMemoryException，显存曲线平坦",
  "PIP 出错时自动停用并在下一帧恢复整屏变焦（failed 闸门未被绕过）",
];
