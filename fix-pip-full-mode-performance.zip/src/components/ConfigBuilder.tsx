import { useMemo, useState } from "react";
import { CodeBlock } from "./ui";

type Profile = "full" | "balanced" | "shader-safe" | "off";

const PROFILES: { id: Profile; name: string; desc: string }[] = [
  {
    id: "full",
    name: "完全模式（问题复现用）",
    desc: "光影 + 二次渲染 + 独立管线。就是本文要修的那个组合：帧率约减半、占用率反而不高。",
  },
  {
    id: "balanced",
    name: "光影下的折中（现在就能用）",
    desc: "保留二次渲染，但把阴影与倍率分担压下来；镜内略软，帧时间明显回落。",
  },
  {
    id: "shader-safe",
    name: "光影 + 重投影（最稳）",
    desc: "不跑第二遍世界渲染，只做屏幕空间放大。没有本文的停顿问题；代价是高倍镜偏软。",
  },
  { id: "off", name: "关闭 PIP（上游行为）", desc: "出任何问题的第一步：改回 false 复测。" },
];

const TOML: Record<Profile, string> = {
  full: `[render]
ScopePipEnable = true
ScopePipRerender = true
ScopePipAllowShaderPacks = true
ScopePipIsolatePipeline = true
ScopePipShadowScale = 0.5
ScopePipWorldZoomShare = 0.0
# ScopeMaskEnable 保持 true（PIP 依赖目镜掩码定位镜片）`,
  balanced: `[render]
ScopePipEnable = true
ScopePipRerender = true
ScopePipAllowShaderPacks = true
ScopePipIsolatePipeline = true
ScopePipShadowScale = 0.25     # 镜内阴影再降一档，先把最贵的通道压下去
ScopePipWorldZoomShare = 0.4   # 把 40% 的倍率还给世界，镜内需要的像素随之减少
AimingSwayIntensity = 1.5`,
  "shader-safe": `[render]
ScopePipEnable = true
ScopePipRerender = false       # 关键：光影下不跑第二遍世界渲染
ScopePipAllowShaderPacks = true
ScopePipSharpness = 0.65
ScopePipWorldZoomShare = 0.35  # 高倍镜嫌软就往上调，1.0 等同关掉 PIP`,
  off: `[render]
ScopePipEnable = false         # 其余 ScopePip* 全部失效，行为与上游一致`,
};

export default function ConfigBuilder() {
  const [p, setP] = useState<Profile>("balanced");
  const toml = useMemo(() => TOML[p], [p]);
  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
      <div className="space-y-2">
        {PROFILES.map((x) => (
          <button
            key={x.id}
            onClick={() => setP(x.id)}
            className={`w-full rounded-xl border p-4 text-left transition ${
              p === x.id
                ? "border-amber-400/40 bg-amber-400/[0.07]"
                : "border-white/10 bg-white/[0.02] hover:border-white/20"
            }`}
          >
            <div className={`text-sm font-medium ${p === x.id ? "text-amber-200" : "text-zinc-200"}`}>
              {x.name}
            </div>
            <div className="mt-1 text-xs leading-relaxed text-zinc-500">{x.desc}</div>
          </button>
        ))}
      </div>
      <div className="space-y-3">
        <p className="text-sm text-zinc-400">
          写入 <code className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-xs text-zinc-300">
            .minecraft/config/tacz-client.toml
          </code>
          ，改完<strong className="text-zinc-200">重启游戏</strong>生效（不是按 R 重载）。
        </p>
        <CodeBlock code={toml} lang="toml" />
      </div>
    </div>
  );
}
