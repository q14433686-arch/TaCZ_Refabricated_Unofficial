import { useState, type ReactNode } from "react";

export function Section({
  id,
  index,
  title,
  kicker,
  children,
}: {
  id: string;
  index: string;
  title: string;
  kicker?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 border-t border-white/10 py-16">
      <div className="mb-8 flex items-start gap-4">
        <span className="mt-1 rounded-lg border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 font-mono text-xs text-amber-300">
          {index}
        </span>
        <div>
          <h2 className="text-2xl font-semibold tracking-tight text-zinc-100 sm:text-3xl">
            {title}
          </h2>
          {kicker && <p className="mt-2 max-w-3xl text-sm text-zinc-400">{kicker}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

export function CodeBlock({ code, lang = "java" }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="group relative overflow-hidden rounded-xl border border-white/10 bg-[#0b0f14]">
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-2">
        <span className="font-mono text-[11px] uppercase tracking-widest text-zinc-500">{lang}</span>
        <button
          onClick={() => {
            navigator.clipboard?.writeText(code);
            setCopied(true);
            setTimeout(() => setCopied(false), 1400);
          }}
          className="rounded-md border border-white/10 px-2 py-1 font-mono text-[11px] text-zinc-400 transition hover:border-amber-400/40 hover:text-amber-300"
        >
          {copied ? "已复制" : "复制"}
        </button>
      </div>
      <pre className="max-h-[28rem] overflow-auto p-4 text-[12.5px] leading-relaxed">
        <code className="font-mono text-zinc-300">
          {code.split("\n").map((line, i) => {
            const cls = line.startsWith("+")
              ? "text-emerald-300"
              : line.startsWith("-")
                ? "text-rose-300/80"
                : /^\s*(\/\/|\*|\/\*)/.test(line)
                  ? "text-zinc-500"
                  : "text-zinc-300";
            return (
              <div key={i} className={cls}>
                {line || " "}
              </div>
            );
          })}
        </code>
      </pre>
    </div>
  );
}

export function Pill({ children, tone = "zinc" }: { children: ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    zinc: "border-white/10 bg-white/5 text-zinc-300",
    amber: "border-amber-400/30 bg-amber-400/10 text-amber-300",
    emerald: "border-emerald-400/30 bg-emerald-400/10 text-emerald-300",
    rose: "border-rose-400/30 bg-rose-400/10 text-rose-300",
    sky: "border-sky-400/30 bg-sky-400/10 text-sky-300",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 font-mono text-[11px] ${tones[tone] ?? tones.zinc}`}
    >
      {children}
    </span>
  );
}
