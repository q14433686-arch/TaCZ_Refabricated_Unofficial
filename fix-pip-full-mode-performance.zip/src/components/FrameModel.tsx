import { useMemo, useState } from "react";
import { Pill } from "./ui";

type Seg = { name: string; ms: number; kind: "gpu" | "cpu" | "stall" };

const FIXES = [
  { id: "swap", label: "P0-1 目标交换（去掉全屏拷贝 + 帧内屏障）" },
  { id: "switch", label: "P0-3 管线切换去抖" },
  { id: "shadow", label: "P1-1 复用主画面阴影贴图" },
  { id: "lens", label: "P1-2 镜内只渲染镜片包围盒" },
  { id: "cull", label: "P1-3 镜内砍掉手部/云/天气/描边" },
  { id: "cadence", label: "P2 镜内降频 interval=2" },
] as const;

type FixId = (typeof FIXES)[number]["id"];

export default function FrameModel() {
  const [on, setOn] = useState<Record<FixId, boolean>>({
    swap: false,
    switch: false,
    shadow: false,
    lens: false,
    cull: false,
    cadence: false,
  });

  const { segs, total, gpuBusy, baseline } = useMemo(() => {
    const lensScale = on.lens ? 0.18 : 1;
    const cadence = on.cadence ? 0.5 : 1;

    const scope: Seg[] = [];
    if (!on.shadow) scope.push({ name: "镜内 shadow pass", ms: 3.5 * cadence, kind: "gpu" });
    scope.push({ name: "镜内 gbuffers", ms: 5.0 * lensScale * cadence, kind: "gpu" });
    scope.push({ name: "镜内 composite 链", ms: 4.0 * lensScale * cadence, kind: "gpu" });
    if (!on.cull) scope.push({ name: "镜内 手部/云/天气/描边", ms: 0.9 * cadence, kind: "gpu" });

    const glue: Seg[] = [];
    if (!on.swap) {
      glue.push({ name: "全屏 copyTextureToTexture", ms: 1.8, kind: "gpu" });
      glue.push({ name: "等待拷贝完成（帧内屏障）", ms: 3.6, kind: "stall" });
    }
    glue.push({
      name: "Iris 管线切换 ×2",
      ms: on.switch ? 0.3 : 1.7,
      kind: "cpu",
    });

    const main: Seg[] = [
      { name: "主画面 shadow pass", ms: 3.5, kind: "gpu" },
      { name: "主画面 gbuffers", ms: 5.0, kind: "gpu" },
      { name: "主画面 composite 链", ms: 4.0, kind: "gpu" },
      { name: "手部 / HUD / present", ms: 1.5, kind: "gpu" },
      { name: "主线程提交", ms: 2.0, kind: "cpu" },
    ];

    const all = [...scope, ...glue, ...main];
    const total = all.reduce((a, b) => a + b.ms, 0);
    const gpu = all.filter((s) => s.kind === "gpu").reduce((a, b) => a + b.ms, 0);
    return {
      segs: all,
      total,
      gpuBusy: gpu / total,
      baseline: 16.0,
    };
  }, [on]);

  const fps = 1000 / total;
  const color = (k: Seg["kind"]) =>
    k === "gpu" ? "bg-sky-500/70" : k === "cpu" ? "bg-violet-500/70" : "bg-rose-500/80";

  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 sm:p-6">
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Pill tone="sky">GPU 工作</Pill>
        <Pill tone="zinc">CPU / 驱动串行</Pill>
        <Pill tone="rose">停顿（谁都不忙 = 占用率掉下去的那一段）</Pill>
      </div>

      <div className="flex h-12 w-full overflow-hidden rounded-lg border border-white/10">
        {segs.map((s, i) => (
          <div
            key={i}
            title={`${s.name} · ${s.ms.toFixed(1)} ms`}
            className={`${color(s.kind)} group relative border-r border-black/30 transition-all duration-500`}
            style={{ width: `${(s.ms / total) * 100}%` }}
          >
            <span className="pointer-events-none absolute inset-0 hidden items-center justify-center text-[10px] text-white/90 group-hover:flex">
              {s.ms.toFixed(1)}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Stat label="帧时间（模型估算）" value={`${total.toFixed(1)} ms`} sub={`无 PIP 基线 ${baseline.toFixed(1)} ms`} />
        <Stat label="帧率" value={`${fps.toFixed(0)} fps`} sub={`基线 ${(1000 / baseline).toFixed(0)} fps`} />
        <Stat
          label="GPU 忙占比"
          value={`${(gpuBusy * 100).toFixed(0)}%`}
          sub={gpuBusy < 0.7 ? "停顿主导：占用率上不去" : "算力主导：占用率正常"}
          tone={gpuBusy < 0.7 ? "rose" : "emerald"}
        />
      </div>

      <div className="mt-6 grid gap-2 sm:grid-cols-2">
        {FIXES.map((f) => (
          <button
            key={f.id}
            onClick={() => setOn((p) => ({ ...p, [f.id]: !p[f.id] }))}
            className={`flex items-center gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition ${
              on[f.id]
                ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-200"
                : "border-white/10 bg-white/[0.02] text-zinc-400 hover:border-white/20"
            }`}
          >
            <span
              className={`grid h-4 w-4 shrink-0 place-items-center rounded border ${
                on[f.id] ? "border-emerald-400 bg-emerald-400/80" : "border-white/20"
              }`}
            >
              {on[f.id] && (
                <svg viewBox="0 0 12 12" className="h-3 w-3 text-black">
                  <path
                    d="M2.5 6.2 4.8 8.5 9.5 3.8"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                  />
                </svg>
              )}
            </span>
            {f.label}
          </button>
        ))}
      </div>
      <p className="mt-4 text-xs leading-relaxed text-zinc-500">
        数值是<strong className="text-zinc-400">量级模型</strong>，用来说明「时间花在哪一类事情上」，不是实测。
        实测方法见 §5 —— 在给出真实读数之前，这张图只允许当作假设，不允许当作结论。
      </p>
    </div>
  );
}

function Stat({
  label,
  value,
  sub,
  tone = "zinc",
}: {
  label: string;
  value: string;
  sub: string;
  tone?: string;
}) {
  const c = tone === "rose" ? "text-rose-300" : tone === "emerald" ? "text-emerald-300" : "text-zinc-100";
  return (
    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
      <div className="text-[11px] uppercase tracking-widest text-zinc-500">{label}</div>
      <div className={`mt-1 font-mono text-2xl ${c}`}>{value}</div>
      <div className="mt-1 text-xs text-zinc-500">{sub}</div>
    </div>
  );
}
