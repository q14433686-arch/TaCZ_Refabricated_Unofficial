export type Snippet = {
  id: string;
  label: string;
  file: string;
  lang: "java" | "glsl" | "toml";
  badge: string;
  badgeTone: "alert" | "flare" | "cool" | "violet";
  note: string;
  code: string;
};

export const SNIPPETS: Snippet[] = [
  {
    id: "legacy",
    label: "现状 · 问题路径",
    file: "client/renderer/model/BedrockPart.java",
    lang: "java",
    badge: "36 万次 / 帧",
    badgeTone: "alert",
    note: "每一帧、每一个实例、每一个顶点都在主线程上重新做一次矩阵乘法，结果用完即弃。",
    code: `// 当前形态：transform-on-submit
public void compile(PoseStack.Pose pose, VertexConsumer vc, int light, int overlay) {
    Matrix4f m = pose.pose();
    Matrix3f n = pose.normal();

    for (Polygon poly : this.polygons) {          // ~120,000 个三角形
        for (Vertex v : poly.vertices()) {        // × 3 = 360,000 顶点
            // 9 次乘加：位置变换
            Vector3f p = m.transformPosition(v.x(), v.y(), v.z(), new Vector3f());
            // 9 次乘加：法线变换  (+ 一次临时对象分配)
            Vector3f nr = n.transform(poly.nx(), poly.ny(), poly.nz(), new Vector3f());

            // 6 次巨态虚调用 / 顶点 —— JIT 无法内联
            vc.addVertex(p.x, p.y, p.z)
              .setColor(255, 255, 255, 255)
              .setUv(v.u(), v.v())
              .setOverlay(overlay)
              .setLight(light)
              .setNormal(nr.x, nr.y, nr.z);
        }
    }
}
// 每帧写出 360,000 × 36 B = 12.9 MB，下一帧全部作废`,
  },
  {
    id: "p0",
    label: "P0 · 姿态哈希缓存",
    file: "client/renderer/cache/PoseByteCache.java",
    lang: "java",
    badge: "1–3 天 · 低风险",
    badgeTone: "flare",
    note: "不改架构的止血手段：矩阵与动画状态未变时，直接 bulk copy 上一帧已经算好的字节块。idle 命中率通常 >70%。",
    code: `/** 姿态未变 → 复用上一帧已变换好的顶点字节块 */
public final class PoseByteCache {
    private long stamp = Long.MIN_VALUE;
    private ByteBuffer baked;   // 直接内存，容量 = vertexCount * 36

    private static long stamp(Matrix4f m, int animTick, int light, int overlay) {
        long h = 1125899906842597L;
        h = h * 31 + Float.floatToRawIntBits(m.m00()); // 只哈希 12 个有效分量
        h = h * 31 + Float.floatToRawIntBits(m.m30());
        h = h * 31 + Float.floatToRawIntBits(m.m31());
        h = h * 31 + Float.floatToRawIntBits(m.m32());
        /* ... 其余分量 ... */
        return (h * 31 + animTick) * 31 + ((long) light << 20 | overlay);
    }

    public boolean tryEmit(Matrix4f m, int animTick, int light, int overlay, ByteBuffer dst) {
        long s = stamp(m, animTick, light, overlay);
        if (s != this.stamp || this.baked == null) return false;   // miss → 走慢路径重建
        this.baked.rewind();
        MemoryUtil.memCopy(this.baked, dst);                        // 命中 → 一次 memcpy
        return true;
    }
}

// 慢路径同样避免逐顶点虚调用：SoA + 直写
static void transformBulk(float[] px, float[] py, float[] pz, int n,
                          Matrix4f m, long dstAddr, int stride) {
    final float a00 = m.m00(), a01 = m.m01(), a02 = m.m02();   // 矩阵系数提到局部变量
    final float a10 = m.m10(), a11 = m.m11(), a12 = m.m12();   // 让 JIT 保持在寄存器里
    final float a20 = m.m20(), a21 = m.m21(), a22 = m.m22();
    final float a30 = m.m30(), a31 = m.m31(), a32 = m.m32();
    for (int i = 0; i < n; i++) {                              // 无分配、无虚调用、可展开
        float x = px[i], y = py[i], z = pz[i];
        long o = dstAddr + (long) i * stride;
        MemoryUtil.memPutFloat(o,     a00 * x + a10 * y + a20 * z + a30);
        MemoryUtil.memPutFloat(o + 4, a01 * x + a11 * y + a21 * z + a31);
        MemoryUtil.memPutFloat(o + 8, a02 * x + a12 * y + a22 * z + a32);
    }
}`,
  },
  {
    id: "p1",
    label: "P1 · 导入期烘焙",
    file: "client/mesh/TMeshBaker.java",
    lang: "java",
    badge: "36 B → 16 B / 顶点",
    badgeTone: "cool",
    note: "把每帧要做的事挪到加载时做一次。焊接 + 索引化 + 量化 + LOD，结果按内容哈希落盘，二次启动零成本。",
    code: `/** 导入期一次性烘焙，运行在虚拟线程池上，主线程零阻塞 */
public record TMesh(
    ByteBuffer vertices,   // 16 B/顶点：pos snorm16×3 + bone u8 + norm RGB10A2 + uv unorm16×2
    IntBuffer  indices,
    Vector3f   aabbMin, Vector3f aabbScale,   // 反量化参数
    int[]      lodIndexCount,                 // LOD0..LOD3 的索引数
    int        boneCount
) {}

public static TMesh bake(RawMesh raw, BakeOptions opt) {
    // 1) 焊接：位置 1e-5 / 法线 1e-3 / UV 1e-5 容差，360K → ~140K 唯一顶点
    Welded w = VertexWelder.weld(raw, opt.tolerance());

    // 2) 三轮重排：post-transform cache → overdraw → vertex fetch
    MeshOpt.optimizeVertexCache(w.indices(), w.vertexCount());
    MeshOpt.optimizeOverdraw(w.indices(), w.positions(), 1.05f);
    MeshOpt.optimizeVertexFetch(w);

    // 3) 刚体骨骼绑定：Bedrock 是层级刚体动画，一个顶点只属于一根骨骼
    byte[] boneIndex = BoneBinder.bindRigid(w, raw.boneTree());

    // 4) 量化：包围盒归一化后落到 snorm16，1 m 尺度量化步长 ≈ 0.015 mm
    Quantized q = VertexQuantizer.pack(w, boneIndex);

    // 5) QEM 简化生成 LOD 链（第一人称永远用 LOD0）
    int[] lodCounts = LodBuilder.build(q, new float[]{1.00f, 0.45f, 0.18f, 0.06f});

    return new TMesh(q.vertices(), q.indices(), q.aabbMin(), q.aabbScale(), lodCounts, raw.boneCount());
}

// 内容哈希磁盘缓存：.minecraft/tacz/.cache/<sha256>.tmesh
Path cache = cacheDir.resolve(Hashing.sha256(rawBytes, BAKER_VERSION) + ".tmesh");
if (Files.exists(cache)) return TMeshIO.mmap(cache);   // 二次启动直接内存映射`,
  },
  {
    id: "p2",
    label: "P2 · GPU 蒙皮提交",
    file: "client/renderer/pipeline/TaczMeshRenderer.java",
    lang: "java",
    badge: "3 KB / 实例 / 帧",
    badgeTone: "violet",
    note: "每帧的 CPU 工作量从 O(顶点数) 变成 O(骨骼数)。12.9 MB 的逐帧写入被 3 KB 的骨骼矩阵调色板取代。",
    code: `/** 每帧提交：只写骨骼矩阵，不碰任何顶点 */
public void submit(GunRenderContext ctx) {
    MeshHandle mesh = arena.resolve(ctx.modelId());        // 常驻显存，不重传
    int lod = LodSelector.pick(ctx.screenCoverage(), ctx.pass());
    if (ctx.pass() == RenderPass.SHADOW) lod = Math.min(lod + 2, 3);   // 阴影降级

    // 骨骼调色板写入 persistent-mapped 环形缓冲：64 × mat4x3 = 3072 B
    int paletteOffset = boneRing.begin(mesh.boneCount());
    long addr = boneRing.address(paletteOffset);
    for (int b = 0; b < mesh.boneCount(); b++) {
        ctx.boneMatrix(b).get4x3(addr + (long) b * 48);    // 12 float / 骨骼
    }

    drawList.add(new DrawItem(mesh, lod, ctx.material(), paletteOffset,
                              ctx.packedLight(), ctx.overlay(), ctx.tint()));
}

/** 帧末刷写：排序合批 → 相同网格实例化 → 1–4 次 draw call */
public void flush(RenderPassEncoder enc) {
    drawList.sort(BY_MATERIAL_THEN_MESH);
    enc.setPipeline(TaczPipelines.SKINNED_GUN);
    enc.setVertexBuffer(0, arena.vertexBuffer());
    enc.setIndexBuffer(arena.indexBuffer(), IndexType.UINT32);
    enc.setUniformBuffer("BonePalette", boneRing.buffer());

    for (Batch batch : Batcher.group(drawList)) {
        enc.bindSampler("Sampler0", batch.texture());
        enc.setUniform("uDequant", batch.mesh().aabbMin(), batch.mesh().aabbScale());
        enc.drawIndexedInstanced(batch.indexOffset(), batch.indexCount(),
                                 batch.firstInstance(), batch.instanceCount());
    }
    boneRing.rotate();   // 三帧轮转，避免 GPU 同步等待
}`,
  },
  {
    id: "glsl",
    label: "P2 · 顶点着色器",
    file: "assets/tacz/shaders/core/skinned_gun.vsh",
    lang: "glsl",
    badge: "变换发生在 GPU",
    badgeTone: "cool",
    note: "36 万次顶点变换对 GPU 是微秒级工作量；对单线程 CPU 是 11 毫秒。这就是整个方案的核心。",
    code: `#version 150

in vec3  aPosQ;       // snorm16 ×3，已归一化到 [-1,1]
in uint  aBone;       // 骨骼索引（导入期烘焙，永不变化）
in vec4  aNormalQ;    // RGB10A2 八面体编码
in vec2  aUv;         // unorm16
in vec2  aUv2;        // light（每实例常量，可走 uniform）

layout(std140) uniform BonePalette {
    mat4x3 uBone[64];             // 3 KB —— 每帧唯一需要上传的数据
};

uniform vec3 uAabbMin;
uniform vec3 uAabbScale;
uniform mat4 uProjViewModel;

out vec2 vUv;
out vec3 vNormal;

void main() {
    // 1) 反量化到模型局部空间
    vec3 localPos = uAabbMin + (aPosQ * 0.5 + 0.5) * uAabbScale;

    // 2) 刚体蒙皮：Bedrock 层级动画 = 每部件一个刚体矩阵，无权重混合
    mat4x3 bone = uBone[aBone];
    vec3 worldPos = bone * vec4(localPos, 1.0);
    vec3 worldNrm = mat3(bone) * decodeOctahedral(aNormalQ);

    // 3) 投影
    gl_Position = uProjViewModel * vec4(worldPos, 1.0);
    vUv     = aUv;
    vNormal = normalize(worldNrm);
}`,
  },
  {
    id: "tier1",
    label: "Tier 1 · 无着色器回退",
    file: "client/renderer/pipeline/PerBoneFallback.java",
    lang: "java",
    badge: "零 CPU 变换 · 最大兼容",
    badgeTone: "flare",
    note: "当 shader pack 不允许注入自定义 program 时的关键退路：顶点仍然常驻显存，只是按骨骼拆成多次绘制，用矩阵 uniform 承载变换。",
    code: `/**
 * 不需要任何自定义着色器，也不需要骨骼属性支持。
 * CPU 成本从 O(360,000) 降到 O(骨骼数)，通常是 8–20。
 */
public void renderPerBone(MeshHandle mesh, GunRenderContext ctx, PoseStack stack) {
    for (BoneSubMesh sub : mesh.boneSubMeshes(ctx.lod())) {
        stack.pushPose();
        ctx.applyBoneTransform(stack, sub.boneId());        // 每骨骼一次矩阵运算

        RenderSystem.setModelViewMatrix(stack.last().pose());
        vanillaLikePipeline.bind(sub.material());
        vanillaLikePipeline.drawIndexed(
            mesh.vertexBuffer(), mesh.indexBuffer(),
            sub.indexOffset(), sub.indexCount());          // 顶点数据从不离开显存

        stack.popPose();
    }
}

// 权衡：draw call 8–20 次 vs 顶点变换 360,000 次。
// 现代驱动上一次 draw call 约 2–8 μs，20 次 = 0.16 ms；
// 360,000 次 CPU 顶点变换 = 约 11 ms。差了近两个数量级。`,
  },
  {
    id: "compat",
    label: "兼容层 · 分级探测",
    file: "client/compat/CompatBridge.java",
    lang: "java",
    badge: "只降级，不崩溃",
    badgeTone: "violet",
    note: "任何一级能力探测失败都会自动落到更保守的层级，并且整个会话只警告一次 —— 与 README 里 PIP 的失败处理策略保持一致。",
    code: `public static Tier detect() {
    if (Config.forcedTier() != null) return Config.forcedTier();     // /tacz mesh tier <n>

    if (RendererProbe.isSulkan()) {
        // 瞄具掩码在 Sulkan 下已经回退，网格管线同样保守处理
        return RendererProbe.supportsPersistentBuffers() ? Tier.T1 : Tier.T2;
    }
    if (IrisApi.isShaderPackInUse()) {
        return IrisBridge.canRegisterProgram(TaczPipelines.SKINNED_GUN) ? Tier.T0 : Tier.T1;
    }
    if (!GpuCaps.supportsUbo(3 * 1024) || !GpuCaps.supportsSnorm16Attrib()) return Tier.T1;
    return Tier.T0;
}

/** 运行时异常一律降级，绝不让渲染中断 */
public static void onPipelineFailure(Throwable t) {
    Tier next = current.degrade();
    if (WARNED.compareAndSet(false, true)) {
        LOGGER.warn("[TaCZ Mesh] 管线 {} 失败，本次会话降级到 {}。请附带日志与 shader pack 版本反馈。",
                    current, next, t);
    }
    current = next;
    MeshCaches.invalidateAll();
}`,
  },
  {
    id: "config",
    label: "配置项",
    file: "config/tacz-client.toml",
    lang: "toml",
    badge: "玩家可自救",
    badgeTone: "flare",
    note: "在改造完成前先给玩家一个开关，同时把量化后的诊断信息暴露出来，方便社区精确回报问题包。",
    code: `[mesh]
# 网格管线层级：auto / 0 / 1 / 2 / legacy
Pipeline = "auto"

# 单个模型顶点数硬上限；超过时加载期告警并自动生成简化版
MaxModelVertices = 120000

# 每帧全局顶点预算，用尽后新实例强制最低 LOD
FrameVertexBudget = 250000

# LOD 切换的屏幕投影面积阈值（占屏幕高度的比例）
LodThresholds = [0.35, 0.12, 0.04]

# 常驻网格显存预算 (MB)，超限按 LRU 驱逐
MeshVramBudgetMB = 256

# 阴影通道跳过第一人称手部几何
ShadowSkipFirstPerson = true

# 导入期烘焙结果的磁盘缓存
DiskCacheEnable = true

# F3 调试叠加：顶点数 / draw call / 上传字节 / Tier 命中率
DebugOverlay = false`,
  },
];
