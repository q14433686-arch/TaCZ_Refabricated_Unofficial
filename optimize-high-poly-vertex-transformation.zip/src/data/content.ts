export const REPO = "https://github.com/q14433686-arch/TaCZ_Refabricated_Unofficial";

/* ------------------------------------------------------------------ */
/* 观测数据                                                            */
/* ------------------------------------------------------------------ */

export const OBSERVED = {
  vertices: 360_000,
  bytesPerVertex: 36, // NEW_ENTITY: pos12 + color4 + uv0 8 + overlay4 + light4 + normal4
  nsPerVertex: 44, // VertexConsumer 路径实测量级（虚调用 + 矩阵变换 + 边界检查）
  budget60: 16.67,
  budget120: 8.33,
};

export const VERTEX_FORMAT = [
  { name: "Position", type: "3 × f32", bytes: 12, note: "每帧被 PoseStack 矩阵重算" },
  { name: "Color", type: "4 × u8", bytes: 4, note: "常量，逐帧重写纯浪费" },
  { name: "UV0 (texture)", type: "2 × f32", bytes: 8, note: "静态，可烘焙" },
  { name: "UV1 (overlay)", type: "2 × i16", bytes: 4, note: "每实例常量" },
  { name: "UV2 (light)", type: "2 × i16", bytes: 4, note: "每实例常量" },
  { name: "Normal", type: "4 × i8", bytes: 4, note: "每帧被法线矩阵重算" },
];

/* ------------------------------------------------------------------ */
/* 根因                                                                */
/* ------------------------------------------------------------------ */

export type RootCause = {
  id: string;
  tag: string;
  title: string;
  severity: "致命" | "严重" | "中等";
  cost: string;
  body: string;
  detail: string[];
};

export const ROOT_CAUSES: RootCause[] = [
  {
    id: "rc1",
    tag: "RC-01",
    title: "提交时变换（transform-on-submit）语义",
    severity: "致命",
    cost: "≈ 11 ms / 帧",
    body:
      "VertexConsumer 契约要求调用方交出「已经在世界空间的顶点」。于是 PoseStack 的 4×4 位置矩阵与 3×3 法线矩阵必须在 CPU 上逐顶点相乘，而算出来的 12.9 MB 结果在下一帧全部作废、从头再算一遍。",
    detail: [
      "36 万顶点 × (9 次乘加做位置 + 9 次乘加做法线) ≈ 每帧 650 万次浮点运算，全部落在 Render Thread。",
      "枪械在静止（idle 动画未推进、玩家未移动视角）时，算出来的结果和上一帧逐位相同，却没有任何复用。",
      "这是架构性开销，不是常数因子问题 —— 微优化最多把 44 ns/顶点压到 12 ns/顶点，仍然是 4 ms。",
    ],
  },
  {
    id: "rc2",
    tag: "RC-02",
    title: "VertexConsumer 抽象层的逐顶点开销",
    severity: "严重",
    cost: "≈ 4 ms / 帧",
    body:
      "addVertex 在真实运行时是巨态（megamorphic）调用点：BufferBuilder、SheetedDecalTextureGenerator、VertexMultiConsumer、Iris 的包装器同时出现，JIT 无法内联，逐顶点付出虚表跳转、容量检查、字节序写入的代价。",
    detail: [
      "每个顶点触发 6 次接口调用（position / color / uv / overlay / light / normal），36 万顶点 = 216 万次巨态虚调用。",
      "PoseStack.Pose#transformNormal 等 API 在部分路径上仍会产生临时 Vector3f，逃逸分析在巨态调用点下经常失效，进而制造 GC 压力。",
      "没有批量提交入口，JIT 无法自动向量化；SIMD 完全用不上。",
    ],
  },
  {
    id: "rc3",
    tag: "RC-03",
    title: "非索引三角汤 + 未量化顶点",
    severity: "严重",
    cost: "2–3× 冗余",
    body:
      "Bedrock / OBJ 网格展开后是逐三角形的顶点流，共享顶点被复制 3–6 次。36 万顶点里真正唯一的通常只有 12–15 万；而 36 字节的顶点格式让每帧写入量维持在 12.9 MB。",
    detail: [
      "焊接 + 索引化后唯一顶点约 14 万，索引 36 万 × u32；CPU 变换量直接下降约 60%。",
      "量化（位置 snorm16 + 包围盒反量化、法线 RGB10A2 八面体编码、UV unorm16）可把顶点从 36 B 压到 16 B。",
      "顶点缓存优化（vertex-cache / overdraw / fetch 三轮重排）还能提升 GPU 端 post-transform cache 命中率。",
    ],
  },
  {
    id: "rc4",
    tag: "RC-04",
    title: "缺少 LOD 与渲染预算，且被多通道放大",
    severity: "严重",
    cost: "×2 ~ ×8",
    body:
      "同一把 36 万面枪，在物品栏图标、掉落物实体、展示框、远处玩家第三人称、Iris 阴影通道、以及 ScopePipRerender 的第二遍世界渲染中，都在跑 LOD0 全精度。",
    detail: [
      "Iris 阴影通道会把手持模型再画一遍（多级联时更多），第一人称手部几何对阴影几乎无贡献。",
      "ScopePipRerender = true 时整个世界渲染两遍，枪械提交也随之翻倍 —— 这正是 README 里「帧率约减半」的一部分来源。",
      "GUI 预览与掉落物实体没有任何理由使用 LOD0，却走同一条 BedrockGunModel 路径。",
    ],
  },
  {
    id: "rc5",
    tag: "RC-05",
    title: "「有动画所以不能缓存 VBO」是个误解",
    severity: "中等",
    cost: "阻塞了正解",
    body:
      "Bedrock 模型的动画是刚体骨骼层级：每个部件（枪机、弹匣、扳机、瞄具）整体做刚体变换，没有逐顶点柔性形变。这意味着可以把顶点永久放进 VBO，每帧只上传一份骨骼矩阵调色板。",
    detail: [
      "每顶点只需一个 u8/u16 的骨骼索引（烘焙进静态缓冲，永不变化）。",
      "每实例每帧上传 64 根骨骼 × mat4x3 = 3 KB，取代 12.9 MB —— 数据量下降 4300 倍。",
      "顶点着色器做 `worldPos = boneMatrix[boneIdx] * localPos`，GPU 上 36 万次变换是微秒级工作。",
    ],
  },
];

/* ------------------------------------------------------------------ */
/* 架构分层                                                            */
/* ------------------------------------------------------------------ */

export type Layer = {
  code: string;
  name: string;
  when: string;
  thread: string;
  color: string;
  items: string[];
};

export const LAYERS: Layer[] = [
  {
    code: "A",
    name: "TMesh Importer · 导入期烘焙",
    when: "枪包加载 / 资源重载时，一次性",
    thread: "工作线程池（Java 25 虚拟线程）",
    color: "flare",
    items: [
      "解析 Bedrock / OBJ → 顶点焊接（位置+法线+UV 容差合并）→ 索引化",
      "meshopt 三轮重排：vertex cache → overdraw → vertex fetch",
      "按骨骼切分子网格，写入每顶点 boneIndex（刚体绑定，无权重混合）",
      "量化：pos snorm16 + AABB、normal RGB10A2 八面体、uv unorm16 → 16 B/顶点",
      "QEM 简化生成 LOD1/2/3（100% / 45% / 18% / 6% 三角形）",
      "序列化为 .tmesh 二进制，按内容哈希落盘到 .minecraft/tacz/.cache/",
    ],
  },
  {
    code: "B",
    name: "GpuMeshArena · 常驻显存资源层",
    when: "首次渲染前，一次性上传",
    thread: "Render Thread（分帧限额 4 MB/帧）",
    color: "cool",
    items: [
      "单个大 GpuBuffer 竞技场（VERTEX + INDEX 各一块），子分配避免频繁创建",
      "MeshHandle = {vertexOffset, indexOffset, indexCount, lodTable[4], boneCount}",
      "显存预算 + LRU 驱逐（默认 256 MB，可配置），超预算时先降 LOD 再驱逐",
      "上传走传输队列，逐帧限额，杜绝切枪瞬间的 stutter",
    ],
  },
  {
    code: "C",
    name: "InstanceCollector · 每帧提交层",
    when: "每帧，每个可见枪械实例",
    thread: "Render Thread（O(骨骼数)，与顶点数无关）",
    color: "violet",
    items: [
      "收集 DrawItem：meshHandle、LOD 级别、材质、骨骼调色板偏移、light/overlay/tint",
      "骨骼矩阵写入 persistent-mapped 环形 UBO/SSBO：64 × mat4x3 = 3 KB / 实例",
      "按 (材质, 网格) 排序合并；完全相同的网格走硬件实例化 drawIndexedInstanced",
      "视锥剔除 + 屏幕投影面积驱动的 LOD 选择 + 每帧顶点预算守卫",
    ],
  },
  {
    code: "D",
    name: "TaczRenderPipeline · GPU 绘制层",
    when: "每帧，1–4 次 draw call",
    thread: "GPU",
    color: "cool",
    items: [
      "自定义 RenderPipeline（26.2 Blaze3D：RenderPass + GpuBuffer + UBO 切片）",
      "顶点着色器完成反量化 → 刚体蒙皮 → MVP，CPU 顶点变换次数归零",
      "Iris 所需的 mc_Entity / at_midBlock / at_tangent 属性在导入期烘焙进静态缓冲",
      "阴影通道强制 LOD+2 并跳过第一人称手部几何",
    ],
  },
  {
    code: "E",
    name: "CompatBridge · 分级兼容层",
    when: "启动 + 渲染器切换时",
    thread: "Render Thread",
    color: "flare",
    items: [
      "探测 Iris / Sodium / Sulkan / Voxy / Physics Mod，选择 Tier 0–3",
      "任何一级失败都自动降级并只警告一次，永不崩溃、永不黑屏",
      "调试指令 /tacz mesh tier <0|1|2|3> 强制固定层级，便于 A/B 对比",
    ],
  },
];

/* ------------------------------------------------------------------ */
/* 分级方案                                                            */
/* ------------------------------------------------------------------ */

export type Tier = {
  id: string;
  name: string;
  subtitle: string;
  cpuTransforms: string;
  upload: string;
  drawCalls: string;
  frameMs: string;
  accent: string;
  when: string;
  how: string[];
};

export const TIERS: Tier[] = [
  {
    id: "T0",
    name: "Tier 0 · GPU 蒙皮直通",
    subtitle: "目标形态",
    cpuTransforms: "0",
    upload: "3 KB",
    drawCalls: "1–2",
    frameMs: "≈0.15 ms",
    accent: "cool",
    when: "原版管线，或 Iris 已接线本 mod 的自定义 program",
    how: [
      "静态量化 VBO 常驻显存，顶点永不重传",
      "骨骼矩阵调色板走 UBO 环形缓冲",
      "顶点着色器完成蒙皮 + 反量化 + MVP",
      "相同网格实例化合批（掉落物 / 展示框 / 多玩家）",
    ],
  },
  {
    id: "T1",
    name: "Tier 1 · 静态 VBO + 逐骨骼绘制",
    subtitle: "无需自定义着色器",
    cpuTransforms: "0",
    upload: "0",
    drawCalls: "8–20",
    frameMs: "≈0.35 ms",
    accent: "flare",
    when: "能建 VBO 但不能注入着色器（部分 shader pack / 未知渲染器）",
    how: [
      "顶点仍然常驻显存，只是按骨骼子网格拆成多次绘制",
      "每次绘制用 modelView 矩阵 uniform 承载该骨骼的变换",
      "CPU 侧成本从 O(顶点数) 降到 O(骨骼数)，仍然是零顶点变换",
      "代价是 draw call 增加，但 8–20 次远低于 36 万次变换",
    ],
  },
  {
    id: "T2",
    name: "Tier 2 · CPU 快路径 + 姿态缓存",
    subtitle: "兼容兜底",
    cpuTransforms: "≤90 K",
    upload: "≈3.2 MB",
    drawCalls: "1–3",
    frameMs: "≈2.6 ms",
    accent: "violet",
    when: "必须走原版 VertexConsumer（严格 shader pack、Sulkan 回退）",
    how: [
      "姿态哈希缓存：矩阵 + 动画状态 + light/overlay 未变则 bulk memcpy 复用字节块",
      "SoA float[] + MemoryUtil 直写，绕开逐顶点巨态虚调用",
      "索引化后唯一顶点只有 ~14 万，配合 LOD 钳制降到 ≤9 万",
      "手写 4 路展开的矩阵乘，热循环内零分配",
    ],
  },
  {
    id: "T3",
    name: "Tier 3 · 预算守卫",
    subtitle: "永不卡死",
    cpuTransforms: "硬上限",
    upload: "受限",
    drawCalls: "1",
    frameMs: "有界",
    accent: "alert",
    when: "帧时间连续超阈值，或单帧顶点预算被击穿",
    how: [
      "每帧全局顶点预算（默认 250 K）用尽后，后续实例强制最低 LOD",
      "超出 MaxModelVertices 的模型加载时即警告作者，并自动生成简化版",
      "HUD 调试叠加层显示：顶点数 / draw call / 上传字节 / 各 Tier 命中率",
    ],
  },
];

/* ------------------------------------------------------------------ */
/* 路线图                                                              */
/* ------------------------------------------------------------------ */

export type Phase = {
  id: string;
  window: string;
  title: string;
  goal: string;
  risk: "低" | "中" | "高";
  gain: string;
  tasks: { t: string; d: string }[];
};

export const PHASES: Phase[] = [
  {
    id: "P0",
    window: "1–3 天 · Hotfix",
    title: "止血：削掉重复与浪费的那几倍",
    goal: "不改架构，先把 ×2~×8 的通道放大和无谓 LOD0 砍掉",
    risk: "低",
    gain: "2–4×",
    tasks: [
      { t: "阴影通道跳过第一人称手部模型", d: "Iris shadow pass 中手部几何对阴影无贡献，直接 return。" },
      { t: "GUI / 掉落物 / 展示框强制低精度", d: "这些场景屏幕占比极小，接入 LOD 前可先用「按屏幕投影面积跳过配件」。" },
      { t: "副手重复渲染去重", d: "同一模型在同帧被 main/off hand 各提交一次时复用同一份缓冲。" },
      { t: "姿态哈希缓存（无 LOD 版）", d: "idle 状态下命中率通常 >70%，直接 memcpy 上一帧字节块。" },
      { t: "热循环去分配", d: "消除 Vector3f/Vector4f 临时对象，矩阵系数提到局部变量。" },
      { t: "新增配置 MaxModelVertices + 日志告警", d: "让玩家能自救，同时把问题精确回传给枪包作者。" },
    ],
  },
  {
    id: "P1",
    window: "1–2 周",
    title: "导入期烘焙：索引化、量化、磁盘缓存、LOD",
    goal: "把「每帧要做的事」搬到「加载时做一次」",
    risk: "中",
    gain: "再 2–3×",
    tasks: [
      { t: "TMesh 二进制格式与内容哈希磁盘缓存", d: "二次启动跳过解析与优化，冷启动时间同步下降。" },
      { t: "顶点焊接 + 索引化 + 三轮重排", d: "唯一顶点 36 万 → ~14 万。" },
      { t: "量化顶点布局 36 B → 16 B", d: "位置 snorm16 + 包围盒反量化，1 米长的枪上误差 < 0.02 mm。" },
      { t: "QEM 生成 LOD1/2/3 并写入 lodTable", d: "屏幕投影面积驱动选择，第一人称恒为 LOD0。" },
      { t: "解析与烘焙移出主线程", d: "虚拟线程池 + 分帧上传限额，消除加载卡顿。" },
    ],
  },
  {
    id: "P2",
    window: "3–4 周",
    title: "GPU 蒙皮管线：让 CPU 顶点变换归零",
    goal: "落地 Tier 0 / Tier 1，架构性解决问题",
    risk: "高",
    gain: "10–60×",
    tasks: [
      { t: "GpuMeshArena 与显存预算 / LRU", d: "基于 26.2 Blaze3D 的 GpuBuffer + RenderPass 抽象。" },
      { t: "骨骼矩阵调色板环形 UBO", d: "persistent mapped，三帧轮转，避免同步等待。" },
      { t: "自定义 RenderPipeline 与顶点着色器", d: "反量化 → 刚体蒙皮 → MVP，一次绘制搞定。" },
      { t: "Tier 1 逐骨骼绘制回退路径", d: "不依赖自定义着色器，兼容面最广的零变换方案。" },
      { t: "Iris 接线与属性烘焙", d: "mc_Entity / at_midBlock / at_tangent 作为静态属性写进 VBO。" },
      { t: "CompatBridge 探测与自动降级", d: "任何异常只降级不崩溃，日志只警告一次。" },
    ],
  },
  {
    id: "P3",
    window: "持续",
    title: "工程化：实例化、工具链、可观测性",
    goal: "让性能可度量、可回归、可被枪包作者自查",
    risk: "低",
    gain: "长尾",
    tasks: [
      { t: "硬件实例化合批", d: "多玩家 / 多掉落物同款枪一次 draw call。" },
      { t: "CLI 工具 taczmesh optimize", d: "枪包作者本地跑简化 + 量化 + LOD，产出即最终格式。" },
      { t: "F3 调试叠加与 spark 埋点", d: "顶点数 / draw call / 上传 MB / Tier 命中率实时可见。" },
      { t: "自动化帧时间回归基线", d: "固定场景 + 固定种子，CI 上跑 p50/p95 帧时间对比。" },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* 兼容矩阵                                                            */
/* ------------------------------------------------------------------ */

export const COMPAT: { env: string; tier: string; note: string; state: "ok" | "warn" | "risk" }[] = [
  { env: "原版渲染器（无 Sodium / 无 Iris）", tier: "Tier 0", note: "完整 GPU 蒙皮，参考实现基线", state: "ok" },
  { env: "Sodium / Embeddium（无 shader pack）", tier: "Tier 0", note: "实体渲染路径未被接管，自定义管线可共存", state: "ok" },
  { env: "Iris + shader pack（已接线）", tier: "Tier 0", note: "需注册 program 并烘焙 Iris 顶点属性", state: "warn" },
  { env: "Iris + 未知/严格 shader pack", tier: "Tier 1", note: "退到逐骨骼绘制，仍是零 CPU 顶点变换", state: "ok" },
  { env: "Sulkan（瞄具掩码已回退）", tier: "Tier 1 / 2", note: "先探测 VBO 能力，不行再退 CPU 快路径", state: "warn" },
  { env: "ScopePipRerender = true", tier: "当前 Tier −1 LOD", note: "第二遍世界渲染复用同一份实例缓冲并降一级 LOD", state: "warn" },
  { env: "Voxy / Distant Horizons", tier: "不受影响", note: "枪械为实体级渲染，与地形 LOD 系统正交", state: "ok" },
  { env: "Physics Mod 投影同步", tier: "Tier 1", note: "自定义管线的矩阵同步需单独验证，先走保守层级", state: "risk" },
];

/* ------------------------------------------------------------------ */
/* 风险                                                                */
/* ------------------------------------------------------------------ */

export const RISKS = [
  {
    r: "shader pack 生态破碎",
    p: "高",
    m: "自定义管线是可选加速路径而非唯一路径；Tier 1 在不接触着色器的前提下同样实现零 CPU 变换，任何探测失败都静默降级。",
  },
  {
    r: "量化带来的精度损失",
    p: "低",
    m: "位置用「每网格包围盒 + snorm16」而非全局量化，1 m 尺度下量化步长约 0.015 mm，远低于枪械模型的建模精度；瞄具准星等关键部件可单独标记为 f32 通道。",
  },
  {
    r: "显存占用上升",
    p: "中",
    m: "量化+索引化后单把 36 万顶点枪约 4 MB 常驻，取代每帧 12.9 MB 流式写入；配 256 MB 预算与 LRU 驱逐，超限先降 LOD。",
  },
  {
    r: "Bedrock 动画语义偏差",
    p: "中",
    m: "GPU 蒙皮必须严格复刻 Bedrock 的 pivot / rotation order / scale 组合顺序；在 CPU 侧保留参考实现，用逐顶点位置差做自动化一致性测试（阈值 1e-4）。",
  },
  {
    r: "改动面过大导致回归",
    p: "中",
    m: "四个阶段各自可独立发布并独立回滚；/tacz mesh tier 指令可在运行时切回 legacy 路径做 A/B。",
  },
];

/* ------------------------------------------------------------------ */
/* 枪包作者指引                                                        */
/* ------------------------------------------------------------------ */

export const PACK_GUIDE = [
  { k: "主枪体三角面", v: "≤ 30 K", bad: "duyupack 量级约 120 K 三角形 / 360 K 顶点" },
  { k: "单个配件三角面", v: "≤ 8 K", bad: "高模瞄具经常单件就超过 40 K" },
  { k: "材质 / 绘制批次", v: "≤ 3 张图集", bad: "每多一张贴图就多一次绘制批次拆分" },
  { k: "导出前处理", v: "Merge by Distance + 三角化", bad: "N-gon 与未焊接顶点会让顶点数虚高 2–3 倍" },
  { k: "细节表达", v: "法线贴图代替几何", bad: "用细分曲面堆螺丝和刻线是主要面数来源" },
  { k: "骨骼数量", v: "≤ 64 根", bad: "超过一个调色板会强制拆分绘制" },
];

/* ------------------------------------------------------------------ */
/* 验证方法                                                            */
/* ------------------------------------------------------------------ */

export const VERIFY = [
  {
    step: "01",
    t: "固定复现场景",
    d: "1080p 窗口锁定；第一人称手持 duyupack + 8 个展示框实例 + 2 个掉落物；关闭 V-Sync 与帧率上限；世界固定种子固定坐标固定视角。",
  },
  {
    step: "02",
    t: "spark 采样定位",
    d: "/spark profiler --thread \"Render thread\" --timeout 60，确认热点集中在 BedrockGunModel#render → VertexConsumer#addVertex，并记录其占 Render Thread 的百分比。",
  },
  {
    step: "03",
    t: "分离 CPU / GPU",
    d: "用 GPU timer query 或 RenderDoc 抓帧，确认瓶颈是提交侧而非填充率；同时记录每帧上传字节数。",
  },
  {
    step: "04",
    t: "A/B 切层",
    d: "/tacz mesh tier 0|1|2|legacy 在同一场景连续切换，每层采集 600 帧，输出 p50 / p95 / p99 帧时间 CSV。",
  },
  {
    step: "05",
    t: "正确性回归",
    d: "GPU 蒙皮结果与 CPU 参考实现逐顶点比对（阈值 1e-4）；截图逐像素 diff 覆盖开镜 / 换弹 / 拉栓 / 枪口火光。",
  },
  {
    step: "06",
    t: "组合矩阵冒烟",
    d: "Iris×3 个主流 shader pack × Sodium × PIP 开关 × Tier 0/1/2，记录实际生效层级与帧时间，作为发布门槛。",
  },
];
