import { Nav } from "./components/Nav";
import { Hero } from "./components/Hero";
import { Diagnosis } from "./components/Diagnosis";
import { RootCauses } from "./components/RootCauses";
import { Architecture } from "./components/Architecture";
import { Tiers } from "./components/Tiers";
import { CodeLab } from "./components/CodeLab";
import { Roadmap } from "./components/Roadmap";
import { Verify } from "./components/Verify";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-ink-950 text-slate-300 antialiased">
      <Nav />
      <main>
        <Hero />
        <Diagnosis />
        <div className="relative">
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
          <RootCauses />
        </div>
        <div className="relative bg-ink-900/40">
          <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
          <div className="relative">
            <Architecture />
          </div>
        </div>
        <Tiers />
        <div className="relative bg-ink-900/40">
          <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
          <div className="relative">
            <CodeLab />
          </div>
        </div>
        <Roadmap />
        <div className="relative bg-ink-900/40">
          <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
          <div className="relative">
            <Verify />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
