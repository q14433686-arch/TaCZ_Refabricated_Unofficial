import { Section, SectionHead, Reveal, Chip } from "./ui";
import { LAYERS } from "../data/content";
import { cn } from "../utils/cn";

function Node({
  title,
  sub,
  tone = "neutral",
  wide,
}: {
  title: string;
  sub?: string;
  tone?: "neutral" | "alert" | "cool" | "flare" | "violet";
  wide?: boolean;
}) {
  const map = {
    neutral: "border-white/10 bg-ink-800 text-slate-300",
    alert: "border-alert-500/40 bg-alert-500/10 text-alert-400",
    cool: "border-cool-400/35 bg-cool-400/10 text-cool-300",
    flare: "border-flare-500/40 bg-flare-500/10 text-flare-300",
    violet: "border-violet-400/35 bg-violet-400/10 text-violet-400",
  } as const;
  return (
    <div
      className={cn(
        "shrink-0 rounded-lg border px-3 py-2.5 text-center",
        map[tone],
        wide ? "min-w-[150px]" : "min-w-[112px]",
      )}
    >
      <div className="font-mono text-[11.5px] font-semibold leading-tight">{title}</div>
      {sub && <div className="mt-1 text-[10px] leading-tight text-slate-500">{sub}</div>}
    </div>
  );
}

function Arrow({ tone = "neutral" }: { tone?: "neutral" | "alert" | "cool" }) {
  const c = tone === "alert" ? "text-alert-500/70" : tone === "cool" ? "text-cool-400/70" : "text-slate-700";
  return <span className={cn("shrink-0 select-none font-mono text-sm", c)}>→</span>;
}

export function Architecture() {
  return (
    <Section id="architecture">
      <SectionHead
        index="03"
        kicker="Architecture"
        title="把「每帧重复的事」搬到「加载时做一次」"
        desc="整套方案是五层结构：导入期烘焙、常驻显存资源、每帧轻量提交、GPU 绘制、分级兼容。核心变化只有一个 —— 顶点数据一旦进了显存就不再回到 CPU。"
        tone="cool"
      />

      {/* pipeline comparison */}
      <Reveal>
        <div className="panel overflow-hidden rounded-2xl">
          {/* current */}
          <div className="border-b border-white/8 p-5 md:p-7">
            <div className="mb-4 flex flex-wrap items-center gap-3">
              <Chip tone="alert">现状 · 每帧全链路重跑</Chip>
              <span className="font-mono text-[11px] text-slate-600">复杂度 O(顶点数 × 帧率 × 通道数)</span>
            </div>
            <div className="relative">
              <div className="flex items-center gap-2.5 overflow-x-auto pb-3">
                <Node title="枪包资源" sub="Bedrock / OBJ" />
                <Arrow />
                <Node title="遍历 360K 顶点" sub="Render Thread" tone="alert" wide />
                <Arrow tone="alert" />
                <Node title="CPU 矩阵变换" sub="650 万次浮点" tone="alert" wide />
                <Arrow tone="alert" />
                <Node title="VertexConsumer" sub="216 万次虚调用" tone="alert" wide />
                <Arrow tone="alert" />
                <Node title="12.9 MB 流式缓冲" sub="逐帧作废" tone="alert" wide />
                <Arrow />
                <Node title="GPU 绘制" sub="几乎闲置" />
              </div>
              <div className="mt-1 flex items-center gap-2 rounded-lg border border-dashed border-alert-500/30 bg-alert-500/5 px-3 py-2">
                <span className="font-mono text-[11px] text-alert-400">↻ 每帧 × 每实例 × 每通道 全部重来</span>
              </div>
            </div>
          </div>

          {/* proposed */}
          <div className="p-5 md:p-7">
            <div className="mb-4 flex flex-wrap items-center gap-3">
              <Chip tone="cool">方案 · 一次烘焙 + 每帧 3 KB</Chip>
              <span className="font-mono text-[11px] text-slate-600">复杂度 O(骨骼数 × 帧率)</span>
            </div>

            <div className="mb-3 flex items-center gap-2 text-[10px]">
              <span className="mono-label rounded border border-white/10 bg-white/5 px-2 py-1 text-slate-500">
                加载期 · 一次
              </span>
              <span className="h-px flex-1 bg-white/8" />
            </div>
            <div className="flex items-center gap-2.5 overflow-x-auto pb-4">
              <Node title="枪包资源" sub="Bedrock / OBJ" />
              <Arrow />
              <Node title="TMesh Importer" sub="焊接·索引·量化·LOD" tone="flare" wide />
              <Arrow />
              <Node title=".tmesh 磁盘缓存" sub="内容哈希" tone="flare" wide />
              <Arrow />
              <Node title="GpuMeshArena" sub="≈4 MB 常驻显存" tone="cool" wide />
            </div>

            <div className="mb-3 flex items-center gap-2 text-[10px]">
              <span className="mono-label rounded border border-cool-400/25 bg-cool-400/10 px-2 py-1 text-cool-300">
                每帧 · 与顶点数无关
              </span>
              <span className="h-px flex-1 bg-white/8" />
            </div>
            <div className="flex items-center gap-2.5 overflow-x-auto">
              <Node title="骨骼矩阵" sub="64 × mat4x3" tone="violet" />
              <Arrow tone="cool" />
              <Node title="环形 UBO" sub="3 KB / 实例" tone="violet" wide />
              <Arrow tone="cool" />
              <Node title="顶点着色器蒙皮" sub="GPU 上做变换" tone="cool" wide />
              <Arrow tone="cool" />
              <Node title="1–4 次 Draw Call" sub="实例化合批" tone="cool" wide />
            </div>
          </div>
        </div>
      </Reveal>

      {/* delta strip */}
      <Reveal delay={80}>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { a: "360,000", b: "0", l: "CPU 顶点变换 / 帧" },
            { a: "12.9 MB", b: "3 KB", l: "每帧上传数据量" },
            { a: "216 万", b: "≈ 0", l: "巨态虚调用 / 帧" },
            { a: "≈15.4 ms", b: "≈0.15 ms", l: "主线程占用" },
          ].map((d, i) => (
            <div key={i} className="panel rounded-xl p-4">
              <div className="mono-label text-slate-600">{d.l}</div>
              <div className="mt-3 flex items-baseline gap-2.5">
                <span className="font-mono text-base text-alert-400/80 line-through decoration-alert-500/50">{d.a}</span>
                <span className="font-mono text-xs text-slate-700">→</span>
                <span className="font-mono text-xl font-bold text-cool-400">{d.b}</span>
              </div>
            </div>
          ))}
        </div>
      </Reveal>

      {/* layers */}
      <div className="mt-14 space-y-4">
        {LAYERS.map((l, i) => {
          const tone =
            l.color === "cool"
              ? { ring: "border-cool-400/30", text: "text-cool-300", bg: "bg-cool-400/10" }
              : l.color === "violet"
                ? { ring: "border-violet-400/30", text: "text-violet-400", bg: "bg-violet-400/10" }
                : { ring: "border-flare-500/30", text: "text-flare-300", bg: "bg-flare-500/10" };
          return (
            <Reveal key={l.code} delay={i * 60}>
              <div className="panel group relative rounded-2xl p-5 transition-colors hover:border-white/15 md:p-7">
                <div className="grid gap-5 md:grid-cols-[220px_1fr]">
                  <div>
                    <div className="flex items-center gap-3">
                      <span
                        className={cn(
                          "grid h-9 w-9 shrink-0 place-items-center rounded-lg border font-mono text-sm font-bold",
                          tone.ring,
                          tone.bg,
                          tone.text,
                        )}
                      >
                        {l.code}
                      </span>
                      <span className="h-px flex-1 bg-white/8 md:hidden" />
                    </div>
                    <h3 className="mt-3.5 text-[15px] font-bold leading-6 text-white">{l.name}</h3>
                    <dl className="mt-3 space-y-1.5">
                      <div className="flex gap-2 text-[11px]">
                        <dt className="w-10 shrink-0 font-mono text-slate-600">时机</dt>
                        <dd className="text-slate-500">{l.when}</dd>
                      </div>
                      <div className="flex gap-2 text-[11px]">
                        <dt className="w-10 shrink-0 font-mono text-slate-600">线程</dt>
                        <dd className="text-slate-500">{l.thread}</dd>
                      </div>
                    </dl>
                  </div>

                  <ul className="grid gap-2.5 self-center border-t border-white/8 pt-4 md:border-l md:border-t-0 md:pl-7 md:pt-0">
                    {l.items.map((it, ii) => (
                      <li key={ii} className="flex gap-3 text-[13px] leading-6 text-slate-400">
                        <span className={cn("mt-2 h-1 w-1 shrink-0 rounded-full", tone.bg, tone.text)} style={{ backgroundColor: "currentColor" }} />
                        <span>{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </Section>
  );
}
