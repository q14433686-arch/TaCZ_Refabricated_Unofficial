import { useState } from "react";
import { Section, SectionHead, Reveal, Chip } from "./ui";
import { ROOT_CAUSES } from "../data/content";
import { cn } from "../utils/cn";

const SEV: Record<string, "alert" | "flare" | "violet"> = {
  致命: "alert",
  严重: "flare",
  中等: "violet",
};

export function RootCauses() {
  const [open, setOpen] = useState<string | null>("rc1");

  return (
    <Section id="rootcause" className="pt-4 md:pt-8">
      <SectionHead
        index="02"
        kicker="Root Cause"
        title="五条根因，其中只有一条需要改架构"
        desc="把「卡」拆成可以分别处理的因子：哪些是浪费、哪些是冗余、哪些是语义错误。只有分清楚，才谈得上分期落地。"
        tone="flare"
      />

      <div className="space-y-3">
        {ROOT_CAUSES.map((rc, i) => {
          const isOpen = open === rc.id;
          return (
            <Reveal key={rc.id} delay={i * 60}>
              <div
                className={cn(
                  "panel overflow-hidden rounded-xl transition-all duration-300",
                  isOpen && "border-flare-500/25 shadow-[0_0_0_1px_rgba(255,140,26,0.08),0_24px_60px_-30px_rgba(255,140,26,0.35)]",
                )}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : rc.id)}
                  className="flex w-full items-start gap-4 px-5 py-5 text-left md:px-7"
                >
                  <span
                    className={cn(
                      "mt-0.5 shrink-0 rounded border px-2 py-1 font-mono text-[11px] font-bold tracking-wider",
                      isOpen
                        ? "border-flare-500/45 bg-flare-500/15 text-flare-300"
                        : "border-white/10 bg-white/5 text-slate-500",
                    )}
                  >
                    {rc.tag}
                  </span>

                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2.5">
                      <span className="text-[15px] font-semibold text-white md:text-base">{rc.title}</span>
                      <Chip tone={SEV[rc.severity]}>{rc.severity}</Chip>
                      <Chip>{rc.cost}</Chip>
                    </span>
                    <span
                      className={cn(
                        "mt-2 text-[13.5px] leading-6 text-slate-400",
                        isOpen ? "block" : "line-clamp-2",
                      )}
                    >
                      {rc.body}
                    </span>
                  </span>

                  <span
                    className={cn(
                      "mt-1 shrink-0 font-mono text-lg text-slate-600 transition-transform duration-300",
                      isOpen && "rotate-45 text-flare-400",
                    )}
                  >
                    +
                  </span>
                </button>

                <div
                  className={cn(
                    "grid transition-all duration-400 ease-out",
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                  )}
                >
                  <div className="overflow-hidden">
                    <ul className="space-y-2.5 border-t border-white/8 bg-ink-900/50 px-5 py-5 md:px-7">
                      {rc.detail.map((d, di) => (
                        <li key={di} className="flex gap-3 text-[13px] leading-6 text-slate-400">
                          <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-flare-500/70" />
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>

      {/* key insight callout */}
      <Reveal delay={120}>
        <div className="relative mt-8 overflow-hidden rounded-2xl border border-cool-400/25 bg-gradient-to-br from-cool-500/10 via-ink-850 to-ink-850 p-6 md:p-9">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-cool-400/10 blur-3xl" />
          <div className="relative">
            <Chip tone="cool">核心判断</Chip>
            <h3 className="mt-4 max-w-3xl text-xl font-bold leading-8 text-white md:text-2xl md:leading-9">
              问题不在「36 万顶点太多」，而在「36 万顶点每秒被 CPU 重算 60 次」。
              <br />
              GPU 处理 36 万顶点是微秒级工作；单线程 CPU 处理它是毫秒级灾难。
            </h3>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-400">
              因此解决方向只有一个：<span className="text-cool-300">把顶点数据搬进显存并且不再搬出来</span>，
              每帧只上传随动画变化的那几十个骨骼矩阵。降面数、加 LOD、优化循环都能缓解，但只有这一步能把复杂度从
              <span className="font-mono text-cool-300"> O(顶点数 × 帧率) </span>
              降到
              <span className="font-mono text-cool-300"> O(骨骼数 × 帧率)</span>。
            </p>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
