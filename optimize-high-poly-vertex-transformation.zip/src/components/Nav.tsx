import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { REPO } from "../data/content";

const LINKS = [
  { id: "diagnosis", label: "诊断" },
  { id: "rootcause", label: "根因" },
  { id: "architecture", label: "架构" },
  { id: "tiers", label: "分级" },
  { id: "code", label: "实现" },
  { id: "roadmap", label: "路线图" },
  { id: "verify", label: "验证" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("diagnosis");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ob = new IntersectionObserver(
      (entries) => {
        const vis = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (vis) setActive(vis.target.id);
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: [0, 0.2, 0.6] },
    );
    LINKS.forEach((l) => {
      const el = document.getElementById(l.id);
      if (el) ob.observe(el);
    });
    return () => ob.disconnect();
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled ? "border-b border-white/8 bg-ink-950/85 backdrop-blur-xl" : "border-b border-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <a href="#top" className="group flex items-center gap-3">
          <span className="relative grid h-8 w-8 place-items-center rounded-md border border-flare-500/40 bg-flare-500/12">
            <span className="h-2.5 w-2.5 rotate-45 border border-flare-400 bg-flare-500/40" />
          </span>
          <span className="leading-tight">
            <span className="block font-mono text-[13px] font-bold tracking-tight text-white">TaCZ Mesh Pipeline</span>
            <span className="mono-label block text-[9px] text-slate-500">RFC · 26.2 高模性能治理</span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              className={cn(
                "relative rounded-md px-3 py-1.5 font-mono text-xs tracking-wide transition-colors",
                active === l.id ? "text-flare-300" : "text-slate-400 hover:text-white",
              )}
            >
              {active === l.id && (
                <span className="absolute inset-0 rounded-md border border-flare-500/25 bg-flare-500/10" />
              )}
              <span className="relative">{l.label}</span>
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={REPO}
            target="_blank"
            rel="noreferrer"
            className="hidden rounded-md border border-white/12 bg-white/5 px-3 py-1.5 font-mono text-xs text-slate-300 transition hover:border-white/25 hover:text-white sm:block"
          >
            GitHub ↗
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="menu"
            className="grid h-9 w-9 place-items-center rounded-md border border-white/12 bg-white/5 lg:hidden"
          >
            <span className="space-y-1">
              <span className="block h-px w-4 bg-slate-300" />
              <span className="block h-px w-4 bg-slate-300" />
              <span className="block h-px w-4 bg-slate-300" />
            </span>
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-white/8 bg-ink-950/95 px-5 py-3 backdrop-blur-xl lg:hidden">
          <div className="grid grid-cols-3 gap-2">
            {LINKS.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                onClick={() => setOpen(false)}
                className="rounded-md border border-white/8 bg-white/5 px-3 py-2 text-center font-mono text-xs text-slate-300"
              >
                {l.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
