import { useState } from "react";
import { Section, SectionHead, Reveal, Chip } from "./ui";
import { SNIPPETS } from "../data/code";
import { CodeBlock } from "./CodeBlock";
import { cn } from "../utils/cn";

export function CodeLab() {
  const [i, setI] = useState(0);
  const s = SNIPPETS[i];

  return (
    <Section id="code">
      <SectionHead
        index="05"
        kicker="Implementation"
        title="从「问题路径」到「目标路径」的具体形状"
        desc={
          <>
            下面是各阶段的参考实现骨架。26.2 的 Blaze3D（GpuBuffer / RenderPass / RenderPipeline）在不同小版本上
            签名会有出入，这里给出的是<span className="text-white">结构与数据流</span>，落地时需要对齐分支上的真实 API。
          </>
        }
        tone="violet"
      />

      <Reveal>
        <div className="flex flex-wrap gap-2">
          {SNIPPETS.map((sn, idx) => (
            <button
              key={sn.id}
              onClick={() => setI(idx)}
              className={cn(
                "rounded-lg border px-3.5 py-2 font-mono text-[11.5px] transition",
                i === idx
                  ? "border-white/28 bg-white/12 text-white"
                  : "border-white/8 bg-white/[0.03] text-slate-400 hover:border-white/20 hover:text-slate-200",
              )}
            >
              {sn.label}
            </button>
          ))}
        </div>
      </Reveal>

      <Reveal delay={60}>
        <div className="panel mt-4 overflow-hidden rounded-2xl">
          {/* header */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 bg-ink-900/70 px-4 py-3 md:px-5">
            <div className="flex min-w-0 items-center gap-3">
              <span className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-alert-500/50" />
                <span className="h-2.5 w-2.5 rounded-full bg-flare-500/50" />
                <span className="h-2.5 w-2.5 rounded-full bg-cool-400/50" />
              </span>
              <span className="truncate font-mono text-[11.5px] text-slate-500">{s.file}</span>
            </div>
            <Chip tone={s.badgeTone}>{s.badge}</Chip>
          </div>

          {/* note */}
          <div className="border-b border-white/8 bg-white/[0.015] px-4 py-3 text-[12.5px] leading-6 text-slate-400 md:px-6">
            {s.note}
          </div>

          {/* code */}
          <div className="bg-[#06080c] p-4 md:p-6">
            <CodeBlock code={s.code} lang={s.lang} />
          </div>
        </div>
      </Reveal>

      {/* three key tricks */}
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {[
          {
            n: "01",
            t: "刚体骨骼 ≠ 柔性蒙皮",
            d: "Bedrock 动画是层级刚体变换，一个顶点只属于一根骨骼。因此 boneIndex 可以在导入期烘焙进静态缓冲，每顶点只多 1 字节，且永远不需要更新。",
            tone: "cool" as const,
          },
          {
            n: "02",
            t: "Iris 属性也是静态的",
            d: "mc_Entity / at_midBlock / at_tangent 这些光影包需要的额外顶点属性，对同一个网格来说是常量。它们同样可以烘焙进 VBO，而不是每帧重新计算写入。",
            tone: "flare" as const,
          },
          {
            n: "03",
            t: "先降级，再优化",
            d: "所有能力探测失败都走更保守的层级并只警告一次。宁可某个 shader pack 下只有 Tier 1 的收益，也不能出现黑屏、崩溃或渲染错乱。",
            tone: "violet" as const,
          },
        ].map((c, idx) => (
          <Reveal key={c.n} delay={idx * 70}>
            <div className="panel h-full rounded-xl p-5">
              <div
                className={cn(
                  "font-mono text-[11px] font-bold tracking-widest",
                  c.tone === "cool" ? "text-cool-400" : c.tone === "flare" ? "text-flare-400" : "text-violet-400",
                )}
              >
                {c.n}
              </div>
              <h4 className="mt-3 text-[15px] font-bold text-white">{c.t}</h4>
              <p className="mt-2.5 text-[13px] leading-6 text-slate-400">{c.d}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
