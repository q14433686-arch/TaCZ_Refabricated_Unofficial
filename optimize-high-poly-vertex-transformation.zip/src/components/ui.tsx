import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

/* ------------------------------------------------------------------ */
/* Reveal on scroll                                                    */
/* ------------------------------------------------------------------ */
export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ob = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setSeen(true);
          ob.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" },
    );
    ob.observe(el);
    return () => ob.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn("reveal", seen && "is-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Section scaffolding                                                 */
/* ------------------------------------------------------------------ */
export function Section({
  id,
  children,
  className,
}: {
  id: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={cn("relative mx-auto w-full max-w-7xl px-5 py-20 sm:px-8 md:py-28", className)}>
      {children}
    </section>
  );
}

export function SectionHead({
  index,
  kicker,
  title,
  desc,
  tone = "flare",
}: {
  index: string;
  kicker: string;
  title: ReactNode;
  desc?: ReactNode;
  tone?: "flare" | "cool" | "violet";
}) {
  const toneMap = {
    flare: "text-flare-400 border-flare-500/30 bg-flare-500/10",
    cool: "text-cool-400 border-cool-400/30 bg-cool-400/10",
    violet: "text-violet-400 border-violet-400/30 bg-violet-400/10",
  } as const;

  return (
    <Reveal>
      <div className="mb-10 md:mb-14">
        <div className="flex items-center gap-3">
          <span className={cn("mono-label rounded border px-2 py-1", toneMap[tone])}>
            {index} / {kicker}
          </span>
          <span className="h-px flex-1 bg-gradient-to-r from-white/15 to-transparent" />
        </div>
        <h2 className="mt-5 max-w-4xl text-3xl font-extrabold leading-[1.2] tracking-tight text-white sm:text-4xl md:text-[2.75rem]">
          {title}
        </h2>
        {desc && <p className="mt-4 max-w-3xl text-[15px] leading-7 text-slate-400 md:text-base">{desc}</p>}
      </div>
    </Reveal>
  );
}

/* ------------------------------------------------------------------ */
/* Bits                                                                */
/* ------------------------------------------------------------------ */
export function Chip({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "flare" | "cool" | "alert" | "violet";
  className?: string;
}) {
  const map = {
    neutral: "border-white/12 bg-white/5 text-slate-300",
    flare: "border-flare-500/35 bg-flare-500/12 text-flare-300",
    cool: "border-cool-400/35 bg-cool-400/12 text-cool-300",
    alert: "border-alert-500/40 bg-alert-500/12 text-alert-400",
    violet: "border-violet-400/35 bg-violet-400/12 text-violet-400",
  } as const;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] tracking-wide",
        map[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Metric({
  value,
  unit,
  label,
  tone = "white",
  sub,
}: {
  value: string;
  unit?: string;
  label: string;
  tone?: "white" | "alert" | "cool" | "flare";
  sub?: string;
}) {
  const map = {
    white: "text-white",
    alert: "text-alert-400",
    cool: "text-cool-400",
    flare: "text-flare-400",
  } as const;
  return (
    <div className="panel rounded-xl p-4 md:p-5">
      <div className={cn("font-mono text-2xl font-bold leading-none tracking-tight md:text-[1.75rem]", map[tone])}>
        {value}
        {unit && <span className="ml-1 text-sm font-medium text-slate-500">{unit}</span>}
      </div>
      <div className="mono-label mt-2.5 text-slate-500">{label}</div>
      {sub && <div className="mt-1.5 text-xs leading-5 text-slate-500">{sub}</div>}
    </div>
  );
}

export function Bar({ pct, tone = "flare" }: { pct: number; tone?: "flare" | "cool" | "alert" | "violet" }) {
  const map = {
    flare: "from-flare-600 to-flare-400",
    cool: "from-cool-500 to-cool-300",
    alert: "from-alert-500 to-alert-400",
    violet: "from-violet-400/70 to-violet-400",
  } as const;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/8">
      <div
        className={cn("h-full rounded-full bg-gradient-to-r transition-[width] duration-700 ease-out", map[tone])}
        style={{ width: `${Math.min(100, Math.max(0.5, pct))}%` }}
      />
    </div>
  );
}
