import { REPO } from "../data/content";
import { Reveal } from "./ui";

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/8 bg-ink-900/60">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-40" />
      <div className="pointer-events-none absolute -bottom-32 left-1/2 h-72 w-[640px] -translate-x-1/2 rounded-full bg-flare-500/10 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-5 py-16 sm:px-8 md:py-20">
        <Reveal>
          <div className="grid gap-10 md:grid-cols-[1.3fr_1fr_1fr]">
            <div>
              <div className="flex items-center gap-3">
                <span className="grid h-8 w-8 place-items-center rounded-md border border-flare-500/40 bg-flare-500/12">
                  <span className="h-2.5 w-2.5 rotate-45 border border-flare-400 bg-flare-500/40" />
                </span>
                <span className="font-mono text-sm font-bold text-white">TaCZ Mesh Pipeline · RFC-001</span>
              </div>
              <p className="mt-4 max-w-md text-[13px] leading-7 text-slate-500">
                本页面是针对「26.2 内置 TaCZ Mesh Loader 在 36 万顶点高模下逐帧 CPU 顶点变换」这一观测现象的
                技术方案讨论稿，用于在 issue / PR 中对齐口径。所有性能数字均为基于顶点格式与调用次数的推算，
                以实机 spark 采样为准。
              </p>
              <a
                href={REPO}
                target="_blank"
                rel="noreferrer"
                className="mt-6 inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/5 px-4 py-2.5 font-mono text-xs text-slate-300 transition hover:border-flare-500/40 hover:text-flare-300"
              >
                q14433686-arch/TaCZ_Refabricated_Unofficial ↗
              </a>
            </div>

            <div>
              <div className="mono-label text-slate-600">方案摘要</div>
              <ul className="mt-4 space-y-2.5 text-[12.5px] leading-6 text-slate-500">
                <li>· 导入期烘焙：焊接 / 索引 / 量化 / LOD / 磁盘缓存</li>
                <li>· 常驻显存竞技场 + 显存预算与 LRU</li>
                <li>· 每帧只上传 3 KB 骨骼矩阵调色板</li>
                <li>· GPU 刚体蒙皮，CPU 顶点变换归零</li>
                <li>· 四级降级，探测失败只降级不崩溃</li>
              </ul>
            </div>

            <div>
              <div className="mono-label text-slate-600">环境基线</div>
              <ul className="mt-4 space-y-2.5 font-mono text-[12px] leading-6 text-slate-500">
                <li>Minecraft 26.2 · Fabric Loader 0.19.3+</li>
                <li>Java 25+ · Fabric API 0.155.2+26.2</li>
                <li>mod 1.1.8+fabric.26.2.R2-hotfix</li>
                <li>参照分支 26.2(main)</li>
              </ul>
            </div>
          </div>
        </Reveal>

        <div className="mt-12 flex flex-col items-start justify-between gap-3 border-t border-white/8 pt-6 md:flex-row md:items-center">
          <p className="font-mono text-[11px] text-slate-600">
            非官方社区移植讨论稿 · 与 TACZ Dev Team 无关 · 代码片段按 GPL-3.0 精神提供
          </p>
          <a href="#top" className="font-mono text-[11px] text-slate-500 transition hover:text-flare-400">
            回到顶部 ↑
          </a>
        </div>
      </div>
    </footer>
  );
}
