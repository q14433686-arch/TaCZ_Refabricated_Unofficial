import { useState } from "react";
import { Section, SectionHead, Reveal, Chip, Bar } from "./ui";
import { PHASES } from "../data/content";
import { cn } from "../utils/cn";

const RISK_TONE = { 低: "cool", 中: "flare", 高: "alert" } as const;

const CUMULATIVE = [
  { id: "现状", ms: 15.4, tone: "alert" as const, note: "单实例、无阴影通道" },
  { id: "P0", ms: 4.6, tone: "flare" as const, note: "去重 + 姿态缓存 + 去分配" },
  { id: "P1", ms: 1.8, tone: "violet" as const, note: "索引化 + 量化 + LOD" },
  { id: "P2", ms: 0.15, tone: "cool" as const, note: "GPU 蒙皮，零 CPU 变换" },
];

export function Roadmap() {
  const [open, setOpen] = useState("P0");
  const max = CUMULATIVE[0].ms;

  return (
    <Section id="roadmap">
      <SectionHead
        index="06"
        kicker="Roadmap"
        title="四期落地，每一期都能独立发布与独立回滚"
        desc="不建议一次性重写渲染路径。先用低风险的 P0 把「重复渲染」和「无谓 LOD0」砍掉止血，再把工作量搬到加载期，最后才动管线。"
        tone="flare"
      />

      {/* cumulative chart */}
      <Reveal>
        <div className="panel mb-8 rounded-2xl p-5 md:p-7">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div className="mono-label text-slate-500">累计收益 · 主线程耗时（36 万顶点，单实例）</div>
            <Chip tone="cool">整体 ≈ 100×</Chip>
          </div>
          <div className="space-y-4">
            {CUMULATIVE.map((c) => (
              <div key={c.id}>
                <div className="mb-1.5 flex items-baseline justify-between gap-4">
                  <span className="flex items-baseline gap-3">
                    <span className="w-10 font-mono text-xs font-bold text-slate-300">{c.id}</span>
                    <span className="text-[12px] text-slate-500">{c.note}</span>
                  </span>
                  <span
                    className={cn(
                      "font-mono text-sm font-bold tabular-nums",
                      c.tone === "alert" ? "text-alert-400" : c.tone === "cool" ? "text-cool-400" : "text-flare-400",
                    )}
                  >
                    {c.ms} ms
                  </span>
                </div>
                <Bar pct={(c.ms / max) * 100} tone={c.tone} />
              </div>
            ))}
          </div>
          <div className="mt-5 flex items-center gap-2 border-t border-white/8 pt-4 font-mono text-[11px] text-slate-600">
            <span className="h-2 w-2 rounded-full bg-white/25" />
            60 FPS 帧预算 16.67 ms · 120 FPS 帧预算 8.33 ms
          </div>
        </div>
      </Reveal>

      {/* phases */}
      <div className="relative space-y-4 md:pl-8">
        <div className="absolute bottom-6 left-[13px] top-6 hidden w-px bg-gradient-to-b from-flare-500/40 via-violet-400/30 to-cool-400/40 md:block" />
        {PHASES.map((p, i) => {
          const on = open === p.id;
          return (
            <Reveal key={p.id} delay={i * 60}>
              <div className="relative">
                <span
                  className={cn(
                    "absolute -left-8 top-6 hidden h-[11px] w-[11px] rounded-full border-2 md:block",
                    on ? "border-flare-400 bg-flare-500" : "border-slate-700 bg-ink-900",
                  )}
                />
                <div
                  className={cn(
                    "panel overflow-hidden rounded-2xl transition-all duration-300",
                    on && "border-white/18",
                  )}
                >
                  <button
                    onClick={() => setOpen(on ? "" : p.id)}
                    className="flex w-full flex-wrap items-center gap-x-4 gap-y-3 px-5 py-5 text-left md:px-7"
                  >
                    <span className="flex min-w-0 flex-1 flex-col gap-2">
                      <span className="flex flex-wrap items-center gap-2.5">
                        <span className="rounded border border-white/12 bg-white/6 px-2 py-0.5 font-mono text-[11px] font-bold text-white">
                          {p.id}
                        </span>
                        <span className="font-mono text-[11px] text-slate-500">{p.window}</span>
                        <Chip tone={RISK_TONE[p.risk]}>风险 {p.risk}</Chip>
                        <Chip tone="cool">收益 {p.gain}</Chip>
                      </span>
                      <span className="text-[15px] font-bold text-white md:text-base">{p.title}</span>
                      <span className="text-[13px] leading-6 text-slate-400">{p.goal}</span>
                    </span>
                    <span
                      className={cn(
                        "shrink-0 font-mono text-lg text-slate-600 transition-transform duration-300",
                        on && "rotate-45 text-flare-400",
                      )}
                    >
                      +
                    </span>
                  </button>

                  <div
                    className={cn(
                      "grid transition-all duration-400 ease-out",
                      on ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                    )}
                  >
                    <div className="overflow-hidden">
                      <div className="border-t border-white/8 bg-ink-900/50 p-5 md:p-7">
                        <div className="grid gap-3 md:grid-cols-2">
                          {p.tasks.map((t, ti) => (
                            <div
                              key={ti}
                              className="rounded-lg border border-white/8 bg-ink-850/70 p-4 transition hover:border-white/16"
                            >
                              <div className="flex items-start gap-2.5">
                                <span className="mt-1 font-mono text-[10px] text-slate-600">
                                  {String(ti + 1).padStart(2, "0")}
                                </span>
                                <div>
                                  <div className="text-[13.5px] font-semibold leading-5 text-slate-100">{t.t}</div>
                                  <div className="mt-1.5 text-[12px] leading-5 text-slate-500">{t.d}</div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </Section>
  );
}
