import { Section, SectionHead, Reveal, Chip } from "./ui";
import { VERIFY, RISKS, PACK_GUIDE } from "../data/content";
import { cn } from "../utils/cn";

export function Verify() {
  return (
    <Section id="verify">
      <SectionHead
        index="07"
        kicker="Verification"
        title="先能量化，再谈优化"
        desc="性能改造最容易翻车的地方是「感觉变快了」。下面是这次讨论建议采用的固定测量流程，以及必须提前对齐的风险与枪包侧约束。"
        tone="cool"
      />

      {/* verify steps */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {VERIFY.map((v, i) => (
          <Reveal key={v.step} delay={i * 55}>
            <div className="panel group relative h-full overflow-hidden rounded-xl p-5 transition hover:border-cool-400/25">
              <span className="pointer-events-none absolute -right-4 -top-5 font-mono text-6xl font-bold text-white/[0.035]">
                {v.step}
              </span>
              <div className="relative">
                <div className="mono-label text-cool-400">STEP {v.step}</div>
                <h4 className="mt-3 text-[15px] font-bold text-white">{v.t}</h4>
                <p className="mt-2.5 text-[12.5px] leading-6 text-slate-400">{v.d}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      {/* risks */}
      <Reveal delay={80}>
        <div className="panel mt-12 overflow-hidden rounded-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-5 py-4 md:px-7">
            <div className="mono-label text-slate-500">风险登记表 · Risk Register</div>
            <Chip tone="flare">每一项都必须有对应的降级路径</Chip>
          </div>
          <div className="divide-y divide-white/5">
            {RISKS.map((r) => (
              <div key={r.r} className="grid gap-3 px-5 py-5 md:grid-cols-[240px_64px_1fr] md:items-start md:gap-6 md:px-7">
                <div className="text-[14px] font-semibold text-white">{r.r}</div>
                <div>
                  <span
                    className={cn(
                      "rounded border px-2 py-1 font-mono text-[10.5px]",
                      r.p === "高"
                        ? "border-alert-500/35 bg-alert-500/10 text-alert-400"
                        : r.p === "中"
                          ? "border-flare-500/35 bg-flare-500/10 text-flare-300"
                          : "border-cool-400/30 bg-cool-400/10 text-cool-300",
                    )}
                  >
                    {r.p}
                  </span>
                </div>
                <div className="text-[13px] leading-6 text-slate-400">{r.m}</div>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* pack guide */}
      <div className="mt-12 grid gap-6 lg:grid-cols-[1.05fr_1fr]">
        <Reveal>
          <div className="panel h-full rounded-2xl p-5 md:p-7">
            <Chip tone="flare">枪包作者侧</Chip>
            <h3 className="mt-4 text-xl font-bold text-white">
              引擎侧能把成本降两个数量级，但预算仍然要有人守
            </h3>
            <p className="mt-3 text-[13.5px] leading-7 text-slate-400">
              Tier 0 之后 CPU 顶点变换归零，但显存占用、绘制批次和 GPU 填充率仍然线性于模型复杂度。
              建议在 <span className="font-mono text-slate-200">gunpack.meta.json</span> 中新增可选的
              <span className="font-mono text-slate-200"> lodHints</span> 与
              <span className="font-mono text-slate-200"> budget</span> 字段，并在加载期对超标模型输出一次明确告警，
              让问题能被精确地回报给内容作者，而不是变成「这个 mod 好卡」。
            </p>
            <div className="mt-6 space-y-2">
              {PACK_GUIDE.map((g) => (
                <div
                  key={g.k}
                  className="flex flex-wrap items-baseline gap-x-3 gap-y-1 rounded-lg border border-white/8 bg-ink-900/50 px-4 py-3"
                >
                  <span className="text-[13px] text-slate-300">{g.k}</span>
                  <span className="font-mono text-[13px] font-bold text-cool-300">{g.v}</span>
                  <span className="w-full text-[11.5px] text-slate-600">{g.bad}</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={80}>
          <div className="panel h-full rounded-2xl p-5 md:p-7">
            <Chip tone="cool">讨论中需要先定下来的三件事</Chip>
            <div className="mt-5 space-y-4">
              {[
                {
                  q: "是否接受新增二进制中间格式（.tmesh）与磁盘缓存目录？",
                  a: "这是把工作量搬到加载期的前提。缓存放在 .minecraft/tacz/.cache/，按内容哈希命名，可随时整目录删除，不影响枪包本体。",
                },
                {
                  q: "自定义 RenderPipeline 的兼容底线画在哪里？",
                  a: "建议明确：Tier 0 只对已验证的 shader pack 组合开启，其余一律 Tier 1。宁可少拿一点收益，也不接受任何渲染错乱进入正式版本。",
                },
                {
                  q: "P0 是否可以先单独发一个 hotfix？",
                  a: "P0 六项改动都不触碰渲染架构，风险最低但能拿到 2–4× 收益，建议与后续架构工作并行推进，先让现有玩家可用。",
                },
              ].map((x, i) => (
                <div key={i} className="rounded-xl border border-white/8 bg-ink-900/50 p-4">
                  <div className="flex gap-3">
                    <span className="mt-0.5 font-mono text-[11px] font-bold text-cool-400">Q{i + 1}</span>
                    <div>
                      <div className="text-[13.5px] font-semibold leading-6 text-white">{x.q}</div>
                      <div className="mt-2 text-[12.5px] leading-6 text-slate-400">{x.a}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
