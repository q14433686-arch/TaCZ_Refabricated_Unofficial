import { type ReactNode } from "react";

const KEYWORDS =
  "public|private|protected|static|final|class|record|interface|enum|return|if|else|for|while|new|void|import|package|extends|implements|this|null|true|false|try|catch|throw|throws|switch|case|break|continue|super|instanceof|synchronized|volatile|transient|native|abstract|default|in|out|uniform|layout|std140|vec2|vec3|vec4|mat3|mat4|mat4x3|int|uint|float|double|long|boolean|byte|short|char|var";

const TYPES =
  "Matrix4f|Matrix3f|Vector3f|Vector4f|PoseStack|VertexConsumer|ByteBuffer|IntBuffer|MemoryUtil|RenderSystem|GpuBuffer|RenderPass|MeshHandle|TMesh|Tier|LOGGER|Math|Files|Path|String|List|Optional";

type Tok = { t: string; c: string | null };

function tokenize(src: string, lang: string): Tok[] {
  const parts: Tok[] = [];
  const kw = lang === "toml" ? "true|false" : KEYWORDS;
  const re = new RegExp(
    [
      `(?<com>\\/\\/[^\\n]*|#[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/)`,
      `(?<str>"(?:[^"\\\\\\n]|\\\\.)*")`,
      `(?<ann>@[A-Za-z_]\\w*)`,
      `(?<num>\\b\\d[\\d_]*(?:\\.\\d+)?[fLdD]?\\b|\\b0x[0-9a-fA-F]+\\b)`,
      `(?<kw>\\b(?:${kw})\\b)`,
      `(?<type>\\b(?:${TYPES})\\b|\\b[A-Z][A-Za-z0-9_]{2,}\\b)`,
      `(?<fn>\\b[a-zA-Z_]\\w*(?=\\s*\\())`,
    ].join("|"),
    "g",
  );

  let last = 0;
  for (const m of src.matchAll(re)) {
    const i = m.index ?? 0;
    if (i > last) parts.push({ t: src.slice(last, i), c: null });
    const g = m.groups ?? {};
    const cls = g.com
      ? "tok-com"
      : g.str
        ? "tok-str"
        : g.ann
          ? "tok-ann"
          : g.num
            ? "tok-num"
            : g.kw
              ? "tok-key"
              : g.type
                ? "tok-type"
                : "tok-fn";
    parts.push({ t: m[0], c: cls });
    last = i + m[0].length;
  }
  if (last < src.length) parts.push({ t: src.slice(last), c: null });
  return parts;
}

export function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const lines = code.split("\n");
  const rendered: ReactNode[] = lines.map((line, li) => {
    const toks = tokenize(line, lang);
    return (
      <div key={li} className="table-row group">
        <span className="table-cell w-10 select-none pr-4 text-right align-top text-[11px] leading-6 text-slate-700">
          {li + 1}
        </span>
        <span className="table-cell whitespace-pre-wrap break-words align-top leading-6">
          {toks.map((t, ti) =>
            t.c ? (
              <span key={ti} className={t.c}>
                {t.t}
              </span>
            ) : (
              <span key={ti}>{t.t}</span>
            ),
          )}
        </span>
      </div>
    );
  });

  return (
    <div className="relative overflow-x-auto">
      <div className="table w-full min-w-full font-mono text-[12.5px] md:text-[13px]">{rendered}</div>
    </div>
  );
}
