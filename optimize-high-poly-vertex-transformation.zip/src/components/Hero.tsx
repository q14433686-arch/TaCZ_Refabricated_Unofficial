import { useEffect, useState } from "react";
import { Chip } from "./ui";
import { REPO } from "../data/content";

function useCount(target: number, ms = 1400) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / ms);
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

export function Hero() {
  const verts = useCount(360000);

  return (
    <div id="top" className="relative isolate overflow-hidden pt-16">
      {/* background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <img
          src="./mesh-hero.png"
          alt=""
          onError={(e) => {
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
          className="absolute right-0 top-0 h-full w-full object-cover opacity-40 md:w-[68%]"
          style={{
            maskImage: "linear-gradient(to right, transparent 0%, black 45%, black 100%)",
            WebkitMaskImage: "linear-gradient(to right, transparent 0%, black 45%, black 100%)",
          }}
        />
        {/* SVG wireframe fallback / overlay — always present so the hero holds up without the bitmap */}
        <svg
          className="absolute right-[4%] top-1/2 hidden h-[420px] w-[52%] -translate-y-1/2 opacity-[0.28] md:block"
          viewBox="0 0 600 400"
          fill="none"
          aria-hidden
        >
          <defs>
            <linearGradient id="wg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#2ed9c3" />
              <stop offset="55%" stopColor="#ff8c1a" />
              <stop offset="100%" stopColor="#ff8c1a" stopOpacity="0.15" />
            </linearGradient>
          </defs>
          {Array.from({ length: 26 }).map((_, i) => (
            <path
              key={`h${i}`}
              d={`M20 ${30 + i * 14} Q 300 ${30 + i * 14 - (i % 2 ? 26 : -18)} 580 ${30 + i * 14}`}
              stroke="url(#wg)"
              strokeWidth="0.5"
              opacity={0.5 - Math.abs(i - 13) * 0.022}
            />
          ))}
          {Array.from({ length: 30 }).map((_, i) => (
            <line
              key={`v${i}`}
              x1={20 + i * 19}
              y1={28}
              x2={20 + i * 19}
              y2={382}
              stroke="url(#wg)"
              strokeWidth="0.4"
              opacity={0.22}
            />
          ))}
        </svg>
        <div className="absolute inset-0 grid-bg opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/60 to-ink-950/90" />
        <div className="absolute -left-40 top-10 h-[420px] w-[420px] rounded-full bg-flare-500/12 blur-[130px]" />
        <div className="absolute bottom-0 right-1/4 h-[360px] w-[520px] rounded-full bg-cool-500/10 blur-[140px]" />
      </div>

      <div className="mx-auto max-w-7xl px-5 pb-16 pt-14 sm:px-8 md:pb-24 md:pt-24">
        <div className="anim-rise flex flex-wrap items-center gap-2">
          <Chip tone="flare">RFC-001</Chip>
          <Chip>Fabric · Minecraft 26.2</Chip>
          <Chip>内置 TaCZ Mesh Loader</Chip>
          <Chip tone="alert">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-alert-400" style={{ animation: "pulseDot 1.6s infinite" }} />
            严重性能卡顿
          </Chip>
        </div>

        <h1
          className="anim-rise mt-7 max-w-5xl text-[2.1rem] font-extrabold leading-[1.12] tracking-tight text-white sm:text-5xl md:text-[4rem]"
          style={{ animationDelay: "80ms" }}
        >
          让 <span className="font-mono text-flare-400 text-glow-flare tabular-nums">{verts.toLocaleString()}</span> 个顶点
          <br className="hidden sm:block" />
          从主线程彻底消失
        </h1>

        <p
          className="anim-rise mt-6 max-w-2xl text-[15px] leading-7 text-slate-400 md:text-lg md:leading-8"
          style={{ animationDelay: "160ms" }}
        >
          在 26.2 的 VertexConsumer 架构下，像 <span className="font-mono text-slate-200">duyupack</span> 这样的
          36 万顶点高模，CPU 每一帧都在渲染线程上重做 36 万次顶点变换、并把 12.9 MB 结果写进内存 —— 然后下一帧全部丢弃。
          <span className="text-slate-200"> 这不是常数因子问题，是提交语义问题。</span>
          下面是一套分四期落地、带完整降级路径的改造方案。
        </p>

        {/* frame budget visual */}
        <div className="anim-rise mt-10 max-w-3xl" style={{ animationDelay: "240ms" }}>
          <div className="mb-2 flex items-baseline justify-between font-mono text-[11px] tracking-wide text-slate-500">
            <span>60 FPS 帧预算 = 16.67 ms</span>
            <span className="text-alert-400">单把高模枪 ≈ 15.4 ms（92%）</span>
          </div>
          <div className="relative h-9 w-full overflow-hidden rounded-lg border border-white/10 bg-ink-850">
            <div className="absolute inset-y-0 left-0 flex w-[92%] items-center bg-gradient-to-r from-alert-500/70 to-flare-500/60 px-3">
              <span className="font-mono text-[11px] font-semibold text-white/95">
                CPU 顶点变换 + VertexConsumer 提交
              </span>
            </div>
            <div className="absolute inset-y-0 right-0 w-[8%] bg-white/5" />
            <div className="absolute inset-y-0 right-[8%] w-px bg-white/40" />
            <div
              className="pointer-events-none absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-white/12 to-transparent"
              style={{ animation: "scan 3.6s linear infinite" }}
            />
          </div>
          <div className="mt-2 font-mono text-[11px] text-slate-600">
            剩余 1.3 ms 要装下：整个世界渲染 · 实体 · 粒子 · UI · 客户端 tick
          </div>
        </div>

        <div className="anim-rise mt-10 flex flex-wrap items-center gap-3" style={{ animationDelay: "320ms" }}>
          <a
            href="#architecture"
            className="group inline-flex items-center gap-2 rounded-lg border border-flare-500/50 bg-flare-500/15 px-5 py-3 text-sm font-semibold text-flare-300 transition hover:bg-flare-500/25 hover:text-white"
          >
            查看方案架构
            <span className="transition-transform group-hover:translate-x-0.5">→</span>
          </a>
          <a
            href="#diagnosis"
            className="inline-flex items-center gap-2 rounded-lg border border-white/12 bg-white/5 px-5 py-3 text-sm font-medium text-slate-300 transition hover:border-white/25 hover:text-white"
          >
            先看开销拆解
          </a>
          <a
            href={REPO}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-1 py-3 font-mono text-xs text-slate-500 transition hover:text-slate-300"
          >
            q14433686-arch/TaCZ_Refabricated_Unofficial ↗
          </a>
        </div>
      </div>

      {/* bottom strip */}
      <div className="border-y border-white/8 bg-ink-900/60">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-white/8 px-5 sm:px-8 md:grid-cols-4">
          {[
            { v: "360,000", l: "顶点 / 模型", s: "duyupack 量级", tone: "text-alert-400" },
            { v: "12.9 MB", l: "每帧写入", s: "36 B × 36 万，逐帧作废", tone: "text-alert-400" },
            { v: "21.6 M/s", l: "顶点变换吞吐", s: "@60fps，单实例单线程", tone: "text-flare-400" },
            { v: "×2 – ×8", l: "多通道放大", s: "副手 / 阴影 / PIP / 展示框", tone: "text-flare-400" },
          ].map((m, i) => (
            <div key={i} className="px-4 py-6 md:px-6 md:py-7">
              <div className={`font-mono text-xl font-bold tracking-tight md:text-2xl ${m.tone}`}>{m.v}</div>
              <div className="mono-label mt-2 text-slate-500">{m.l}</div>
              <div className="mt-1 text-[11px] leading-4 text-slate-600">{m.s}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
