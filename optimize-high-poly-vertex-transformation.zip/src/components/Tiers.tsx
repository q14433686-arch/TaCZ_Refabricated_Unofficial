import { useState } from "react";
import { Section, SectionHead, Reveal, Chip } from "./ui";
import { TIERS, COMPAT } from "../data/content";
import { cn } from "../utils/cn";

const TONE = {
  cool: { border: "border-cool-400/35", text: "text-cool-300", bg: "bg-cool-400/10", dot: "bg-cool-400" },
  flare: { border: "border-flare-500/35", text: "text-flare-300", bg: "bg-flare-500/10", dot: "bg-flare-500" },
  violet: { border: "border-violet-400/35", text: "text-violet-400", bg: "bg-violet-400/10", dot: "bg-violet-400" },
  alert: { border: "border-alert-500/35", text: "text-alert-400", bg: "bg-alert-500/10", dot: "bg-alert-500" },
} as const;

const STATE = {
  ok: { label: "已覆盖", cls: "text-cool-300 border-cool-400/30 bg-cool-400/10" },
  warn: { label: "需接线", cls: "text-flare-300 border-flare-500/30 bg-flare-500/10" },
  risk: { label: "待验证", cls: "text-alert-400 border-alert-500/30 bg-alert-500/10" },
} as const;

export function Tiers() {
  const [active, setActive] = useState(0);

  return (
    <Section id="tiers">
      <SectionHead
        index="04"
        kicker="Tiered Fallback"
        title="四级降级：任何环境都不会比现在更糟"
        desc={
          <>
            光影包生态是这类改造最大的风险面。因此自定义管线被设计成「可选加速路径」而不是唯一路径 —— 
            即使完全无法注入着色器，<span className="text-white">Tier 1 依然做到零 CPU 顶点变换</span>。
            探测失败只降级、不崩溃，与仓库里 Scope PIP 的失败处理策略保持一致。
          </>
        }
        tone="cool"
      />

      {/* tier selector */}
      <Reveal>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {TIERS.map((t, i) => {
            const tone = TONE[t.accent as keyof typeof TONE];
            const on = active === i;
            return (
              <button
                key={t.id}
                onClick={() => setActive(i)}
                className={cn(
                  "panel group relative overflow-hidden rounded-xl p-4 text-left transition-all duration-300 md:p-5",
                  on ? cn(tone.border, "bg-white/[0.045]") : "hover:border-white/18",
                )}
              >
                {on && <span className={cn("absolute inset-x-0 top-0 h-0.5", tone.dot)} />}
                <div className="flex items-center justify-between">
                  <span className={cn("font-mono text-xs font-bold tracking-wider", on ? tone.text : "text-slate-500")}>
                    {t.id}
                  </span>
                  <span className="mono-label text-[9px] text-slate-600">{t.subtitle}</span>
                </div>
                <div className={cn("mt-3 text-[13.5px] font-semibold leading-5", on ? "text-white" : "text-slate-300")}>
                  {t.name.split(" · ")[1]}
                </div>
                <div className="mt-4 grid grid-cols-2 gap-y-2 border-t border-white/8 pt-3">
                  <div>
                    <div className="mono-label text-[9px] text-slate-600">CPU 变换</div>
                    <div className={cn("font-mono text-sm font-bold", tone.text)}>{t.cpuTransforms}</div>
                  </div>
                  <div>
                    <div className="mono-label text-[9px] text-slate-600">主线程</div>
                    <div className="font-mono text-sm font-bold text-white">{t.frameMs}</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </Reveal>

      {/* detail */}
      <Reveal delay={60}>
        <div className="panel mt-4 rounded-2xl p-5 md:p-8">
          {(() => {
            const t = TIERS[active];
            const tone = TONE[t.accent as keyof typeof TONE];
            return (
              <div className="grid gap-8 md:grid-cols-[1fr_1.1fr]">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={cn("rounded border px-2 py-1 font-mono text-[11px] font-bold", tone.border, tone.bg, tone.text)}>
                      {t.id}
                    </span>
                    <h3 className="text-lg font-bold text-white md:text-xl">{t.name.split(" · ")[1]}</h3>
                  </div>
                  <div className="mt-4 rounded-lg border border-white/8 bg-ink-900/60 px-4 py-3">
                    <div className="mono-label text-slate-600">生效条件</div>
                    <div className="mt-1.5 text-[13px] leading-6 text-slate-300">{t.when}</div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    {[
                      { k: "CPU 顶点变换", v: t.cpuTransforms },
                      { k: "每帧上传", v: t.upload },
                      { k: "Draw Call", v: t.drawCalls },
                      { k: "主线程耗时", v: t.frameMs },
                    ].map((m) => (
                      <div key={m.k} className="rounded-lg border border-white/8 bg-ink-900/40 px-3.5 py-3">
                        <div className="mono-label text-[9px] text-slate-600">{m.k}</div>
                        <div className={cn("mt-1.5 font-mono text-base font-bold", tone.text)}>{m.v}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="mono-label mb-3 text-slate-600">实现要点</div>
                  <ul className="space-y-3">
                    {t.how.map((h, i) => (
                      <li key={i} className="flex gap-3.5">
                        <span className={cn("mt-2 h-1.5 w-1.5 shrink-0 rounded-full", tone.dot)} />
                        <span className="text-[13.5px] leading-6 text-slate-400">{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })()}
        </div>
      </Reveal>

      {/* compat matrix */}
      <Reveal delay={100}>
        <div className="panel mt-10 overflow-hidden rounded-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-5 py-4 md:px-7">
            <div>
              <div className="mono-label text-slate-500">兼容矩阵 · 预期生效层级</div>
              <div className="mt-1 text-[13px] text-slate-500">
                每一格都要在发布前用固定场景实测，而不是靠推断填写。
              </div>
            </div>
            <Chip>/tacz mesh tier &lt;0|1|2|legacy&gt; 可运行时强制</Chip>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-white/8 text-left">
                  {["运行环境", "预期层级", "状态", "说明"].map((h) => (
                    <th key={h} className="mono-label px-5 py-3 font-normal text-slate-600 md:px-7">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPAT.map((c) => (
                  <tr key={c.env} className="border-b border-white/5 last:border-0 hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5 text-[13px] text-slate-200 md:px-7">{c.env}</td>
                    <td className="px-5 py-3.5 font-mono text-[12.5px] text-white md:px-7">{c.tier}</td>
                    <td className="px-5 py-3.5 md:px-7">
                      <span className={cn("rounded-full border px-2.5 py-1 font-mono text-[10.5px]", STATE[c.state].cls)}>
                        {STATE[c.state].label}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-[12.5px] text-slate-400 md:px-7">{c.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
