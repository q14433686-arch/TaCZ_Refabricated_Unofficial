import { useMemo, useState } from "react";
import { Section, SectionHead, Reveal, Chip, Bar } from "./ui";
import { VERTEX_FORMAT } from "../data/content";
import { cn } from "../utils/cn";

type TierKey = "legacy" | "t2" | "t1" | "t0";

const TIER_META: Record<TierKey, { name: string; tone: "alert" | "violet" | "flare" | "cool"; desc: string }> = {
  legacy: { name: "现状 legacy", tone: "alert", desc: "逐帧 CPU 变换 + VertexConsumer" },
  t2: { name: "Tier 2", tone: "violet", desc: "索引化 + 姿态缓存 + 直写" },
  t1: { name: "Tier 1", tone: "flare", desc: "静态 VBO + 逐骨骼绘制" },
  t0: { name: "Tier 0", tone: "cool", desc: "GPU 蒙皮，零 CPU 变换" },
};

const OTHER_FRAME_MS = 4.5; // 世界渲染 / 实体 / UI 的基础开销假设

function estimate(verts: number, instances: number, mult: number, tier: TierKey) {
  const submissions = instances * mult;
  let transforms = 0;
  let bytes = 0;
  let cpuMs = 0;
  let drawCalls = 0;

  if (tier === "legacy") {
    transforms = submissions * verts;
    bytes = transforms * 36;
    cpuMs = (transforms * 44) / 1e6;
    drawCalls = submissions * 2;
  } else if (tier === "t2") {
    const eff = verts * 0.39 /* 索引化 */ * 0.75 /* LOD 钳制 */ * 0.65; /* 姿态缓存未命中 */
    transforms = Math.round(submissions * eff);
    bytes = Math.round(submissions * verts * 0.39 * 0.75 * 20);
    cpuMs = (transforms * 16) / 1e6;
    drawCalls = submissions * 2;
  } else if (tier === "t1") {
    transforms = 0;
    bytes = 0;
    drawCalls = submissions * 14;
    cpuMs = submissions * 0.02 + drawCalls * 0.004;
  } else {
    transforms = 0;
    bytes = submissions * 3072;
    drawCalls = Math.max(1, Math.ceil(submissions / 6)) * 2;
    cpuMs = submissions * 0.012 + drawCalls * 0.004;
  }

  const gpuMs = (submissions * verts * (tier === "legacy" ? 0.45 : 0.32)) / 1e6;
  const fps = 1000 / (cpuMs + OTHER_FRAME_MS);
  return { submissions, transforms, bytes, cpuMs, gpuMs, drawCalls, fps };
}

function fmtBytes(b: number) {
  if (b >= 1 << 20) return `${(b / (1 << 20)).toFixed(1)} MB`;
  if (b >= 1 << 10) return `${(b / (1 << 10)).toFixed(1)} KB`;
  return `${b} B`;
}

export function Diagnosis() {
  const [verts, setVerts] = useState(360000);
  const [instances, setInstances] = useState(1);
  const [shadow, setShadow] = useState(true);
  const [offhand, setOffhand] = useState(false);
  const [pip, setPip] = useState(false);
  const [tier, setTier] = useState<TierKey>("legacy");

  const mult = (1 + (shadow ? 1 : 0) + (offhand ? 1 : 0)) * (pip ? 2 : 1);
  const r = useMemo(() => estimate(verts, instances, mult, tier), [verts, instances, mult, tier]);
  const base = useMemo(() => estimate(verts, instances, mult, "legacy"), [verts, instances, mult]);

  const budget = 16.67;
  const pct = (r.cpuMs / budget) * 100;

  return (
    <Section id="diagnosis">
      <SectionHead
        index="01"
        kicker="Diagnosis"
        title="先把开销算清楚：这不是「模型有点大」，是提交语义的量纲错误"
        desc={
          <>
            VertexConsumer 要求调用方交出已经变换到世界空间的顶点。于是模型复杂度直接乘进了每帧的 CPU 工作量，
            而 GPU 在整个过程中几乎闲置。下面的估算器用来对齐讨论口径 —— 拖动参数，看它在什么条件下击穿帧预算。
          </>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_1.15fr]">
        {/* controls */}
        <Reveal>
          <div className="panel h-full rounded-2xl p-5 md:p-7">
            <div className="mono-label mb-5 text-slate-500">Input · 场景参数</div>

            <label className="block">
              <div className="flex items-baseline justify-between">
                <span className="text-sm text-slate-300">单模型顶点数</span>
                <span className="font-mono text-sm font-bold text-white tabular-nums">{verts.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min={20000}
                max={600000}
                step={10000}
                value={verts}
                onChange={(e) => setVerts(+e.target.value)}
                className="mt-3 w-full accent-flare-500"
              />
              <div className="mt-1 flex justify-between font-mono text-[10px] text-slate-600">
                <span>20K 常规枪包</span>
                <span>360K duyupack</span>
                <span>600K</span>
              </div>
            </label>

            <label className="mt-6 block">
              <div className="flex items-baseline justify-between">
                <span className="text-sm text-slate-300">同屏实例数</span>
                <span className="font-mono text-sm font-bold text-white tabular-nums">{instances}</span>
              </div>
              <input
                type="range"
                min={1}
                max={16}
                step={1}
                value={instances}
                onChange={(e) => setInstances(+e.target.value)}
                className="mt-3 w-full accent-flare-500"
              />
              <div className="mt-1 font-mono text-[10px] text-slate-600">第一人称 + 其他玩家 + 掉落物 + 展示框</div>
            </label>

            <div className="mono-label mb-3 mt-7 text-slate-500">渲染通道放大</div>
            <div className="space-y-2">
              {[
                { on: shadow, set: setShadow, t: "Iris 阴影通道", d: "手持几何被再画一遍（多级联时更多）" },
                { on: offhand, set: setOffhand, t: "副手同模型", d: "同帧内主/副手各提交一次" },
                { on: pip, set: setPip, t: "ScopePipRerender", d: "整个世界渲染两遍 → 提交翻倍" },
              ].map((o, i) => (
                <button
                  key={i}
                  onClick={() => o.set(!o.on)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition",
                    o.on ? "border-flare-500/40 bg-flare-500/10" : "border-white/8 bg-white/[0.03] hover:border-white/20",
                  )}
                >
                  <span
                    className={cn(
                      "relative h-4 w-7 shrink-0 rounded-full transition",
                      o.on ? "bg-flare-500/70" : "bg-white/12",
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all",
                        o.on ? "left-3.5" : "left-0.5",
                      )}
                    />
                  </span>
                  <span className="min-w-0">
                    <span className={cn("block text-[13px] font-medium", o.on ? "text-white" : "text-slate-300")}>
                      {o.t}
                    </span>
                    <span className="block truncate text-[11px] text-slate-500">{o.d}</span>
                  </span>
                </button>
              ))}
            </div>

            <div className="mt-5 flex items-center justify-between rounded-lg border border-white/8 bg-ink-900 px-3 py-2.5">
              <span className="mono-label text-slate-500">有效提交次数</span>
              <span className="font-mono text-sm font-bold text-flare-400">
                {instances} × {mult} = {r.submissions}
              </span>
            </div>
          </div>
        </Reveal>

        {/* output */}
        <Reveal delay={90}>
          <div className="panel h-full rounded-2xl p-5 md:p-7">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <div className="mono-label text-slate-500">Output · 每帧成本估算</div>
              <div className="flex flex-wrap gap-1.5">
                {(Object.keys(TIER_META) as TierKey[]).map((k) => (
                  <button
                    key={k}
                    onClick={() => setTier(k)}
                    className={cn(
                      "rounded-md border px-2.5 py-1 font-mono text-[11px] transition",
                      tier === k
                        ? "border-white/30 bg-white/12 text-white"
                        : "border-white/8 bg-white/[0.03] text-slate-400 hover:text-white",
                    )}
                  >
                    {TIER_META[k].name}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-5 flex items-center gap-2">
              <Chip tone={TIER_META[tier].tone}>{TIER_META[tier].desc}</Chip>
            </div>

            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                {
                  v: r.transforms >= 1000 ? `${(r.transforms / 1000).toFixed(0)}K` : `${r.transforms}`,
                  l: "CPU 顶点变换",
                  tone: r.transforms === 0 ? "text-cool-400" : r.transforms > 300000 ? "text-alert-400" : "text-flare-400",
                },
                { v: fmtBytes(r.bytes), l: "每帧写入", tone: r.bytes > 8e6 ? "text-alert-400" : "text-slate-200" },
                { v: `${r.drawCalls}`, l: "Draw Call", tone: "text-slate-200" },
                {
                  v: `${r.cpuMs.toFixed(2)}`,
                  l: "主线程 ms",
                  tone: r.cpuMs > 8 ? "text-alert-400" : r.cpuMs > 2 ? "text-flare-400" : "text-cool-400",
                },
              ].map((m, i) => (
                <div key={i} className="rounded-xl border border-white/8 bg-ink-900/70 p-3.5">
                  <div className={cn("font-mono text-xl font-bold tabular-nums", m.tone)}>{m.v}</div>
                  <div className="mono-label mt-2 text-slate-600">{m.l}</div>
                </div>
              ))}
            </div>

            <div className="mt-6">
              <div className="mb-2 flex items-baseline justify-between font-mono text-[11px]">
                <span className="text-slate-500">占 60 FPS 帧预算（16.67 ms）</span>
                <span className={cn(pct > 100 ? "text-alert-400" : pct > 40 ? "text-flare-400" : "text-cool-400")}>
                  {pct.toFixed(0)}%
                </span>
              </div>
              <Bar pct={pct} tone={pct > 100 ? "alert" : pct > 40 ? "flare" : "cool"} />
              {pct > 100 && (
                <div className="mt-2 font-mono text-[11px] text-alert-400">
                  ⚠ 仅枪械提交就超出整个帧预算 —— 帧率被单一模型钉死
                </div>
              )}
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3 border-t border-white/8 pt-5">
              <div>
                <div className="mono-label text-slate-600">估算可达帧率</div>
                <div className="mt-1.5 font-mono text-2xl font-bold text-white tabular-nums">
                  {Math.round(r.fps)} <span className="text-sm font-medium text-slate-500">fps</span>
                </div>
                <div className="mt-1 text-[11px] text-slate-600">假设其余渲染开销 {OTHER_FRAME_MS} ms</div>
              </div>
              <div>
                <div className="mono-label text-slate-600">相对现状加速</div>
                <div
                  className={cn(
                    "mt-1.5 font-mono text-2xl font-bold tabular-nums",
                    tier === "legacy" ? "text-slate-500" : "text-cool-400",
                  )}
                >
                  {tier === "legacy" ? "基准" : `${(base.cpuMs / Math.max(r.cpuMs, 0.001)).toFixed(1)}×`}
                </div>
                <div className="mt-1 text-[11px] text-slate-600">
                  GPU 侧估算 {r.gpuMs.toFixed(2)} ms（远未饱和）
                </div>
              </div>
            </div>

            <p className="mt-5 text-[11px] leading-5 text-slate-600">
              * 估算模型：legacy 取 44 ns/顶点（含巨态虚调用与边界检查），Tier 2 取 16 ns/顶点并计入索引化 0.39×、
              LOD 钳制 0.75×、姿态缓存命中 35%；Tier 0/1 的成本与顶点数无关。实际数值需以 spark 采样为准，
              此处只用于统一讨论量纲。
            </p>
          </div>
        </Reveal>
      </div>

      {/* vertex format */}
      <Reveal delay={120}>
        <div className="panel mt-6 overflow-hidden rounded-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-5 py-4 md:px-7">
            <div>
              <div className="mono-label text-slate-500">NEW_ENTITY 顶点格式 · 36 字节</div>
              <div className="mt-1 text-sm text-slate-400">
                其中真正「每帧会变」的只有 <span className="text-flare-400">位置 12 B</span> 与
                <span className="text-flare-400"> 法线 4 B</span>，其余 20 B 是逐帧重复写入的常量。
              </div>
            </div>
            <Chip tone="alert">20 / 36 B 是纯浪费</Chip>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b border-white/8 text-left">
                  {["字段", "类型", "字节", "占比", "说明"].map((h) => (
                    <th key={h} className="mono-label px-5 py-3 font-normal text-slate-600 md:px-7">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {VERTEX_FORMAT.map((f) => (
                  <tr key={f.name} className="border-b border-white/5 last:border-0 hover:bg-white/[0.02]">
                    <td className="px-5 py-3 font-mono text-[13px] text-slate-200 md:px-7">{f.name}</td>
                    <td className="px-5 py-3 font-mono text-[12px] text-slate-500 md:px-7">{f.type}</td>
                    <td className="px-5 py-3 font-mono text-[13px] text-white md:px-7">{f.bytes}</td>
                    <td className="w-32 px-5 py-3 md:px-7">
                      <Bar pct={(f.bytes / 12) * 100} tone={f.bytes >= 8 ? "flare" : "violet"} />
                    </td>
                    <td className="px-5 py-3 text-[12.5px] text-slate-400 md:px-7">{f.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Reveal>
    </Section>
  );
}
